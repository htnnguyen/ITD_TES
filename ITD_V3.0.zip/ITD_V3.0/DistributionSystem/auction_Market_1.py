#	Copyright (C) 2017 Battelle Memorial Institute
import json
import sys
import warnings
import csv
import fncs
import math
import cmath
import re
import matplotlib.pyplot as plt
#from loadforecast import loadforecast_RP

def defaultinitilization():

    return 0

def initAuction(auctionDict):

    return 0

def check_voltage(voltage_list):
	LeastVoltage = 2401.7771
	HighestVoltage = 0.0
	#phase = voltage_list[0][1]
	for item in voltage_list:
		if item[2] < LeastVoltage:
			LeastVoltage = item[2]
	for item in voltage_list:
		if item[2] > HighestVoltage:
			HighestVoltage = item[2]
	if LeastVoltage < (0.9*2401.7771):
		Adjust_tap = 1
	elif HighestVoltage > (1.1*2401.7771):
		Adjust_tap = -1
	else:
		Adjust_tap = 0
	return Adjust_tap
	
def monitor_powerflow(power_listz,power_maximum):
	for power_list in power_listz:
		for i in range(15):
			#print(power_list)
			if ((power_list[0]==node_index[i]) and (power_list[1]==phase_index[i])):
				
				if (power_list[2]>power_maximum):
					for j in range(12):
						fncs.publish('house_'+str(i+1)+'_'+str(j+1), ThermostatMode_action)
				else:
					for j in range(12):
						fncs.publish('house_'+str(i+1)+'_'+str(j+1), ThermostatMode_default)
	return 0
def monitor_energyflow():
	return 0

load = []	
hour_len = 3600 #100 # in s
day_len = 24* hour_len # in s

def loadforecast_RP(loadforecast, h, d):
	time = []
	LSE2 = [200, 176.8,	161.47,	153.73,	146.13,	149.93,	153.73,	169.2, 207.6,	238.4,	246.13,	249.93,	246.13,	238.4,	234.6,	234.6, 249.93,	284.53,	269.2,	265.26,	261.47,	253.73,	234.6,	211.53]
	LSE1 = [250.00,	222.93,	205.04,	196.02,	187.16,	191.59,	196.02,	214.07, 258.86,	294.8,	303.82,	308.25,	303.82,	294.8,	290.37,	290.37, 308.25,	348.62,	330.73,	326.14,	321.71,	312.69,	290.37,	263.46]
	LSE3 = [287.50,	259.89,	244.06,	230.63,	224.44,	226.52,	240.97,	265.73, 291.54,	317.35,	338.00,	346.26,	345.24,	342.15,	342.15,	352.45, 360.72,	368.95,	376.15,	377.17,	363.78,	348.31,	332.17,	302.98]
	#old_stdout = sys.stdout
	#log_file = open("loadforecast.player","a+")
	#sys.stdout = log_file
	loadforecastRTM = [[] for i in range(3)]
	loadforecastDAM = []
	unit = 1 #1000000000
#	load = []
	
	#24 hour vector -> DAM
	if(len(loadforecast) > 1):
		x = (d* day_len)*unit + ((hour_len)/2)*unit - 1*unit 
		for j in range(24):
			loadforecast[j] = float(loadforecast[j])/1000
			load.append((x,'loadforecastDAM_h'+str(j), float(loadforecast[j])*1)) # replace 1 with 
	else:
		#RTM
		y = (h* hour_len)*unit + (d)*(day_len)*unit + ((hour_len)/2)*unit - 1*unit #10*10*1000000000
		loadforecast[0] = float(loadforecast[0])/1000
		load.append((y, 'loadforecastRTM_'+str(2), + float(LSE2[h]+loadforecast[0])*1))
		load.append((y, 'loadforecastRTM_'+str(1), float(LSE1[h])))
		load.append((y, 'loadforecastRTM_'+str(3), float(LSE3[h])))
	#print()
	#for i in load:
	#	print(str(i[0])+'	'+str(i[1])+'	'+str(i[2]))
	#sys.stdout = old_stdout
	#log_file.close()
	return None
	
    # ====================extract float from string ===============================
def get_num(self,fncs_string):
    return float(''.join(ele for ele in fncs_string if ele.isdigit() or ele == '.'))
def get_number(value):
	return float(''.join(ele for ele in value if ele.isdigit() or ele == '.'))

def get_number_ames(value):
	for char in value:
		if char in "'":
			value.replace(char,'')
	#print("value is ",value,flush=True)
	return get_number(value)
	

def subscribeValHVAC(fncs_sub_value_String, Correction):
	# Assign values to buyers
	P = []
	Pi = []
	SumMustON = 0
	SumMayRunON = 0
	SumMayRunOFF = 0
	#Pi_all = []
	controllerKeys = list (fncs_sub_value_String['controller'].keys())
	#print('checking controllerKeys length', len(controllerKeys), flush = True)
	for i in range(len(controllerKeys)):
		#print('checking controller length', len(controller['name']), flush = True)
		for j in range(len(controller['name'])):
			#print('checking controller name: ', controller['name'][j], controllerKeys[i], flush = True)
			if controller['name'][j] == controllerKeys[i]:
				#print('air temperature: ', fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature'], flush=True)
				#print('state1: ', fncs_sub_value_String['controller'][controllerKeys[i]]['state'], flush=True)
				Tbliss_val = 72 #controller['Tbliss'][j] 
				d_val = 4 #controller['d'][j]
				theta_val = 1 #controller['theta'][j]
				Ta_val = fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature']
				#S = controller['name'][j].split('_thermostat_controller')
				P_val = fncs_sub_value_String['controller'][controllerKeys[i]]['quantity'] * 1000
				PAvg_val = fncs_sub_value_String['controller'][controllerKeys[i]]['PAvg'] * 1000
				if P_val ==0:
					P_val = 3500
				#print('P_val', P_val, flush=True)
				if Ta_val >= Tbliss_val + d_val:
					Correction = Correction + P_val
					SumMustON = SumMustON + P_val
				if Tbliss_val < Ta_val and Ta_val < Tbliss_val + d_val:
					#Pi_all.append(controller['theta'][j] * fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature'])
					if fncs_sub_value_String['controller'][controllerKeys[i]]['state'] == 'COOL':
						SumMayRunON = SumMayRunON + P_val
						#print('SumMayRunON1', SumMayRunON, flush = True)
						#print('state2: ', fncs_sub_value_String['controller'][controllerKeys[i]]['state'], flush=True)
						controller['air_temperature'][j] = fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature']
						PiStar = theta_val * (Ta_val - Tbliss_val)/d_val
						Pi.append(PiStar)
						P.append(PAvg_val)
					else:
						SumMayRunOFF = SumMayRunOFF + P_val
						controller['air_temperature'][j] = fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature']
						PiStar = theta_val * (Ta_val - Tbliss_val)/d_val
						Pi.append(PiStar)
						P.append(PAvg_val)
				elif Tbliss_val - d_val < Ta_val and Ta_val < Tbliss_val:
					#Pi_all.append(controller['theta'][j] * fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature'])
					if fncs_sub_value_String['controller'][controllerKeys[i]]['state'] == 'COOL':
						SumMayRunON = SumMayRunON + P_val
						#print('SumMayRunON2', SumMayRunON, flush = True)
						#print('state2: ', fncs_sub_value_String['controller'][controllerKeys[i]]['state'], flush=True)
						controller['air_temperature'][j] = fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature']
						PiStar = theta_val * (Ta_val - Tbliss_val)/d_val
						Pi.append(PiStar)
						P.append(PAvg_val)
					else:
						SumMayRunOFF = SumMayRunOFF + P_val
						controller['air_temperature'][j] = fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature']
						PiStar = theta_val * (Ta_val - Tbliss_val)/d_val
						Pi.append(PiStar)
						P.append(PAvg_val)
				#print('P value: ', controller['P'][j], flush=True)
				#print('Pi value: ', controller['theta'][j] * fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature'], flush=True)
				#print('Pi vector: ', Pi)
			#print('Pi val: ', Pi_all, flush= True)
	#print('P val: ', P, flush=True)
	#print('In SubscribeVal SumMayRunON', SumMayRunON, flush = True)
	return Correction, P, Pi, SumMayRunON, SumMayRunOFF, SumMustON

	
def calClearPrice(error, P, Pi, SumMayRunON):
	#print('printing Pi list:', Pi, flush = True)
	sum = 0
	ErrorMet = 0
	#[Pi_sorted, indexlist] = sort_prices(Pi)
	P_sorted = []
	Pi_sorted = []
	indexlist = []
	sortedlist = sorted(enumerate(Pi), key = lambda x: x[1])
	sortedlist_reverse = sorted(sortedlist, key = lambda x: x[1], reverse = True)
	#print('printing sorted list:', sortedlist, flush = True)
	#print('printing sorted_reverse list:', sortedlist_reverse, flush = True)
	for i in sortedlist_reverse:
		indexlist.append(i[0])
		Pi_sorted.append(i[1])
	#print('printing index list:', indexlist, flush = True)
	if len(Pi_sorted) > 0:
		print('printing Pi_sorted list:', Pi_sorted, flush = True)
	for i in range(len(indexlist)):
		P_sorted.append(P[indexlist[i]])
	#print('printing P_sorted list:', P_sorted, flush = True)
	#print('printing length Pi_sorted:', len(Pi_sorted), flush = True)
	CP = 1.0
	if error <= 0:
		if len(Pi_sorted) > 0:
			CP = Pi_sorted[0] + 0.01
			#print('CP1:', CP, flush = True)
			# for i in range(len(P_sorted)):
				# ErrorMet = -1 * SumMayRunON
			ErrorMet = 0
		else:
			CP = 1.0
			print('CP2:', CP, flush = True)
			ErrorMet = 0
	elif error >0:
		if len(Pi_sorted) > 0:
			CP = Pi_sorted[0] + 0.01
			#print('CP3:', CP, flush = True)
			for i in range(len(P_sorted)):
				diff1 = abs(sum - error)
				ErrorMet = sum
				sum = sum + P_sorted[i]
				#print('printing sum:', sum, error, flush = True)
				#print('printing current Pi_sorted[i]:', Pi_sorted[i], flush = True)
				diff2 = abs(sum - error)
				if sum >= error:
					if diff1 > diff2:
						ErrorMet = sum
						CP = Pi_sorted[i]
					if CP > 1:
						CP = 1
					if CP < -1:
						CP = -1
					#print('printing4 ErrorSignalNew, ErrorMet', error, ErrorMet, flush = True)
					#print('CP4:', CP, flush = True)
					return CP, ErrorMet
				CP = Pi_sorted[i]
				#print('printing prev Pi_sorted[i]:', CP, flush = True)
		else:
			CP = 1.0
			#print('CP5:', CP, flush = True)
	if CP > 1:
		CP = 1
	if CP < -1:
		CP = -1
	#print('printing ErrorSignalNew, ErrorMet', error, ErrorMet, flush = True)
	#print('CP:', CP, flush = True)
	return CP, ErrorMet


#def publish_publications(value, mode, index):
def publish_Price(value):
	#print('checking before updation',fncs_publish['auction'][market['name']]['price_cap']['propertyValue'], flush = True)
	fncs_publish['auction'][market['name']]['market_id']['propertyValue'] = 1
	fncs_publish['auction'][market['name']]['std_dev']['propertyValue'] = 0.01
	fncs_publish['auction'][market['name']]['average_price']['propertyValue'] = 0.02078
	fncs_publish['auction'][market['name']]['clear_price'] = value
	fncs_publish['auction'][market['name']]['price_cap']['propertyValue'] = 3.78
	fncs_publish['auction'][market['name']]['period']['propertyValue'] = 300
	fncs_publish['auction'][market['name']]['initial_price']['propertyValue'] = 0.02078
	
	fncs_publishString = json.dumps(fncs_publish)
	fncs.agentPublish(fncs_publishString)
	fncs.publish('clear_price', value)
	# for i in range(15):
		# for j in range(12):
			# print('publishing WPDAM: ', value,flush = True)
			# fncs.publish('clear_price'+'_'+'house_'+str(i+1)+'_'+str(j+1), value)
	return 0

def getfromcsv(day, hour):
	f = open('base_line.csv','r')
	reader = csv.reader(f)
	for i, line in enumerate(reader):
		if i == 24*60*day + 60*hour:
			#print(float(line[0], flush = True)
			return float(line[0])

def bline_append(base_line):
	old_stdout = sys.stdout
	log_file = open("base_line_intermediate.csv","a+")
	sys.stdout = log_file
	print(base_line, flush=True)
	sys.stdout = old_stdout
	log_file.close()
	return None

def	dload_append(d_loadNew):
	old_stdout = sys.stdout
	log_file = open("dload_intermediate.csv","a+")
	sys.stdout = log_file
	print(d_loadNew, flush=True)
	sys.stdout = old_stdout
	log_file.close()
	return None

def clprice_append(clprice_temp):
	old_stdout = sys.stdout
	log_file = open("clprice_intermediate.csv","a+")
	sys.stdout = log_file
	for i in range(len(clprice_temp)):
		print(clprice_temp[i], flush=True)
	sys.stdout = old_stdout
	log_file.close()
	return None

def plotfn():
	bline = []
	dload = []
	clprice = []
	f = open('base_line_intermediate.csv','r')
	reader = csv.reader(f)
	for line in reader:
		bline.append(float(line[0]))
	f.close()
	
	f = open('dload_intermediate.csv','r')
	reader = csv.reader(f)
	for line in reader:
		dload.append(float(line[0]))
	f.close()

	f = open('clprice_intermediate.csv','r')
	reader = csv.reader(f)
	for line in reader:
		clprice.append(float(line[0]))
	f.close()
	#print('*******DLOAD**************')
	#print(dload, flush = True)
	#print('*******BLINE**************')
	#print(bline, flush = True)

	#prepare stick
	ind =[ i for i in range(0,len(dload)+int(hour_factor),int(hour_factor))]
	str_stick =[ str(int((i+0.00001)/hour_factor)) for i in ind]
	#Plotting dload and bline
	fig = plt.figure(1)
	plt.subplot(211)
	t = range(len(dload))
	p1=plt.plot(t, dload, 'b', )
	p2=plt.plot(t, bline, 'r', )
	plt.xlabel("Time (h)")
	plt.ylabel("Power (W)")
	plt.xticks(ind,str_stick)
	#plt.grid(True)


	#now you can plot the price  clprice ?????????????????????????????????????????????????????????
	plt.subplot(212)
	t2 = range(len(clprice))
	p3=plt.plot(t2, clprice,)
	plt.xlabel("Time (h)")
	plt.ylabel("Price ($/kWh)")
	plt.xticks(ind,str_stick)
	plt.legend((p1[0], p2[0], p3[0]), ('Actual Household Load (Price Controlled)', 'Target Load','Price Signal'))
	#plt.grid(True)
	plt.show()

	##print('***********************************Price**************************************************', flush=True)
	##print(clprice, flush=True)

	return None


tapA = 0
tapB = 0
tapC = 0
voltage_listA=[]
voltage_listB=[]
voltage_listC=[]
distribution_load = 600000
power_listA=[]
power_listB=[]
power_listC=[]
energy_listA = []
energy_listQ = []
WPDAM = [0.0 for i in range(24)]
WPDAMModified = [0.0 for i in range(24*60)]
RP = [0.0 for i in range(24*60)]
delTRP = 60
deltaT = 30#30  # simulation time interval in seconds(minutes), which usually the same as controller period 
hour_factor = 3600/(deltaT)
num_sub_intervals = int(300/deltaT)
#dload = []
#bline = []
clprice = []
delTAuction = 1
delTBreakeven = 300 #86400
CostIncurred24Hr = 0.0
Correction = 0
sub_time=0
SumMustON = 0
SumMayRunON = 0
SumMayRunOFF = 0
day = 0
hour = 0

with warnings.catch_warnings():
	warnings.simplefilter("ignore") # TODO - pypower is using NumPy doubles for integer indices
	#warnings.filterwarnings("ignore",category=DeprecationWarning)
	stats = {'stat_mode': [], 'interval': [], 'stat_type': [], 'value': [], 'statistic_count': 0}
	market = {'name': 'none',' period': -1, 'latency': 0, 'market_id': 1, 'network': 'none', 'linkref': 'none', 'pricecap': 0.0, 
					'special_mode': 'MD_NONE', 'statistic_mode': 1, 'fixed_price': 50.0, 'fixed_quantity': 0.0,
					'init_price': 0.0, 'init_stdev': 0.0, 'future_mean_price': 0.0, 'use_future_mean_price': 0, 
					'capacity_reference_object': {'name': 'none', 'capacity_reference_property': 0.0, 'capacity_reference_bid_price': 0.0, 
                                                 'max_capacity_reference_bid_quantity': 0.0, 'capacity_reference_bid_quantity': 0.0},
					'current_frame': {'start_time': 0.0, 'end_time': 0.0, 'clearing_price':0.0, 'clearing_quantity': 0.0, 'clearing_type': 'CT_NULL', 
                                      'marginal_quantity': 0.0, 'total_marginal_quantity': 0.0, 'marginal_frac': 0.0, 'seller_total_quantity': 0.0, 
                                      'buyer_total_quantity': 0.0, 'seller_min_price': 0.0, 'buyer_total_unrep': 0.0, 'cap_ref_unrep': 0.0, 
                                      'statistics': []}, 
					'past_frame': {'start_time': 0.0, 'end_time': 0.0, 'clearing_price':0.0, 'clearing_quantity': 0.0, 'clearing_type': 'CT_NULL', 
                                      'marginal_quantity': 0.0, 'total_marginal_quantity': 0.0, 'marginal_frac': 0.0, 'seller_total_quantity': 0.0, 
                                      'buyer_total_quantity': 0.0, 'seller_min_price': 0.0, 'buyer_total_unrep': 0.0, 'cap_ref_unrep': 0.0, 
                                      'statistics': []}, 
					'cleared_frame': {'start_time': 0.0, 'end_time': 0.0, 'clearing_price':0.0, 'clearing_quantity': 0.0, 'clearing_type': 'CT_NULL', 
                                      'marginal_quantity': 0.0, 'total_marginal_quantity': 0.0, 'marginal_frac': 0.0, 'seller_total_quantity': 0.0, 
                                      'buyer_total_quantity': 0.0, 'seller_min_price': 0.0, 'buyer_total_unrep': 0.0, 'cap_ref_unrep': 0.0, 
                                      'statistics': []}, 
					'margin_mode': 'AM_NONE', 'ignore_pricecap': 0,'ignore_failedmarket': 0, 'warmup': 1,
					'total_samples': 0,'clearat': 0,  'clearing_scalar': 0.5, 'longest_statistic': 0.0}  
	market_output = {'std': -1, 'mean': -1, 'clear_price': -1, 'market_id': 'none', 'pricecap': 0.0} # Initialize market output with default values
	buyer = {'name': [], 'price': [], 'quantity': [], 'state': [], 'bid_id': []}
	seller = {'name': [], 'price': [], 'quantity': [], 'state': [], 'bid_id': []} 
	nextClear = {'from':0, 'quantity':0, 'price':0}
	offers = {'name': [], 'price': [], 'quantity': []}
	controller = {'name': [], 'price': [], 'quantity': [], 'state': [], 'Tbliss': [], 'd': [], 'theta': [], 'P': [], 'houseType': [], 'air_temperature': []}
	housedata = {'name': 'none', 'air_temperature': 78, 'state': 'ON', 'Tbliss': 75, 'd': 10, 'theta': 1.0, 'P': 2.1, 'houseType': 'none', 'price': 0.0, 'quantity': 0.0}
	housedataArray = []
	PControlSignal = 10

	if len(sys.argv) == 7:
		filename = sys.argv[1]
		rootname = sys.argv[2]
		StartTime = sys.argv[3]
		tmax = int(sys.argv[4])
		dt = int(sys.argv[5])
		case = int(sys.argv[6])
	elif len(sys.argv) == 1:
		rootname = 'ppcase'
		StartTime = "2013-07-01 00:00:00"
		dt = 3600
		tmax = 2 * 24 * 3600
		case = 1
	else:
		print ('usage: python fncsPYPOWER.py [rootname StartTime tmax dt]')
		sys.exit()
	AvgsumRealPower = [[0 for i in range(24)] for j in range(int(tmax/(24*3600)+1))]
	lp = open(filename).read()
	auctionDict = json.loads(lp)
	agentRegistration = auctionDict['registration']
	agentInitialVal = auctionDict['initial_values']
	#print('Market Name', agentRegistration['agentName'], market['name'], flush = True)
	market['name'] = agentRegistration['agentName']
	print('Market Name', agentRegistration['agentName'], market['name'], flush = True)
	# Read and assign initial values from agentInitialVal
	# Market information
	market['special_mode'] = agentInitialVal['market_information']['special_mode']
	market['market_id'] = agentInitialVal['market_information']['market_id']
	market['use_future_mean_price'] = agentInitialVal['market_information']['use_future_mean_price']
	market['pricecap'] = agentInitialVal['market_information']['pricecap']
	market['clearing_scalar'] = agentInitialVal['market_information']['clearing_scalar']
	market['period'] = agentInitialVal['market_information']['period']
	market['latency'] = agentInitialVal['market_information']['latency']
	market['init_price'] = agentInitialVal['market_information']['init_price']
	market['init_stdev'] = agentInitialVal['market_information']['init_stdev']
	market['ignore_pricecap'] = agentInitialVal['market_information']['ignore_pricecap']
	market['ignore_failedmarket'] = agentInitialVal['market_information']['ignore_failedmarket']
	market['statistic_mode'] = agentInitialVal['market_information']['statistic_mode']
	market['capacity_reference_object']['name'] = agentInitialVal['market_information']['capacity_reference_object']
	market['capacity_reference_object']['max_capacity_reference_bid_quantity'] = agentInitialVal['market_information']['max_capacity_reference_bid_quantity']
	# Stats information
	stats['stat_mode'] = agentInitialVal['statistics_information']['stat_mode']
	stats['interval'] = agentInitialVal['statistics_information']['interval']
	stats['stat_type'] = agentInitialVal['statistics_information']['stat_type']
	stats['value'] = agentInitialVal['statistics_information']['value']
	# Controller information
	controller['name'] = agentInitialVal['controller_information']['name']
	controller['price'] = agentInitialVal['controller_information']['price']
	controller['quantity'] = agentInitialVal['controller_information']['quantity']
	controller['state'] = agentInitialVal['controller_information']['state']
	#print('check Tbliss:', agentInitialVal['controller_information']['Tbliss'], flush = True)
	controller['Tbliss'] = agentInitialVal['controller_information']['Tbliss']
	controller['d'] = agentInitialVal['controller_information']['d']
	controller['theta'] = agentInitialVal['controller_information']['theta']
	controller['P'] = agentInitialVal['controller_information']['P']
	controller['houseType'] = agentInitialVal['controller_information']['houseType']
	controller['air_temperature'] = agentInitialVal['controller_information']['air_temperature']

	RealPowerkWh = {}
	for i in range(len(controller['name'])):
		S = controller['name'][i].split('_thermostat_controller')
		RealPowerkWh[S[0]] = {'real_power_kWh' : 0.0, 'energybillRevenue': 0.0, 'Prev_real_power_kWh' : 0.0, 'energybillCost': 0.0}
	#print('Realpowerkwhhouse: ', RealPowerkWh, flush=True)
	for i in range(0,len(agentInitialVal)):
		s = agentInitialVal['controller_information']['name'][i]
		#print('s', s, flush = True)
		housedata['name'] = s
		housedata['price'] = agentInitialVal['controller_information']['price'][i]
		housedata['quantity'] = agentInitialVal['controller_information']['quantity'][i]
		housedata['state'] = agentInitialVal['controller_information']['state'][i]
		housedata['Tbliss'] = agentInitialVal['controller_information']['Tbliss'][i]
		housedata['d'] = agentInitialVal['controller_information']['d'][i]
		housedata['theta'] = agentInitialVal['controller_information']['theta'][i]
		housedata['P'] = agentInitialVal['controller_information']['P'][i]
		housedata['houseType'] = agentInitialVal['controller_information']['houseType'][i]
		housedata['air_temperature'] = agentInitialVal['controller_information']['air_temperature'][i]
		housedataArray.append(housedata)
	# Generate agent publication dictionary
	fncs_publish = {
		'auction': {
			market['name']: {
				'market_id': {'propertyType': 'integer', 'propertyUnit': 'none', 'propertyValue': 0},
				'std_dev': {'propertyType': 'integer', 'propertyUnit': 'none', 'propertyValue': 0.0},
				'average_price': {'propertyType': 'double', 'propertyUnit': 'none', 'propertyValue': 0.0},
				'clear_price': {'propertyType': 'double', 'propertyUnit': 'none', 'propertyValue': 0.0},
				'price_cap': {'propertyType': 'integer', 'propertyUnit': 'none', 'propertyValue': 0.0},
				'period': {'propertyType': 'double', 'propertyUnit': 'none', 'propertyValue': -1.0},
				'initial_price':{'propertyType': 'double', 'propertyUnit': 'none', 'propertyValue': 0.0}
				}
			}
		}
	fncs_publish['auction'][market['name']]['clear_price'] = 0.002
	fncs.publish('clear_price', 0.002)
	ts = 0
	tnext = 0
	tnextBill = 300
	dtBill = 300 #2592000
	MonthlyBill = 20
	fncs.initialize()
	iter = 1
	line_no = 10;
	timeSim = 0
#	ts = -dt
#	while ts <= tmax:
#		ts += dt
	p = 0.0167
	a = 0.004
	c = -1
	while ts <= tmax:
		#print ("looping", ts, tnext, tmax, flush=True)
		# if ts >= tnext:
			# c = c + 1
			# fncs.publish('LMP_B7', 0.0157)			
			# tnext += dt
			# if tnext > tmax:
				# print ('breaking out at',tnext,flush=True)
				# break
		if ts >= tnextBill:
			fncs.publish('MonthlyBill', MonthlyBill)
			tnextBill += dtBill
			if tnextBill > tmax:
				print ('breaking out at',tnextBill,flush=True)
				break
		tnext += delTAuction
		ts = fncs.time_request(tnext)
		#print ('ts0: ',ts, flush = True)
		fncs_sub_value_unicode = (fncs.agentGetEvents()).decode()
		if fncs_sub_value_unicode != '':
			#Global variables
			#P = []
			#Pi = []
			#P_sorted = []
			#Pi_sorted = []
			Correction = 0
			fncs_sub_value_String = json.loads(fncs_sub_value_unicode)
			#print('SumMayRunON', SumMayRunON, flush = True)
			if "controller" in fncs_sub_value_String:
				#print('Entered subscribeVal if loop', flush = True)
				Correction, P, Pi, SumMayRunON, SumMayRunOFF, SumMustON = subscribeValHVAC(fncs_sub_value_String, Correction)
				#print('P values1: ', P, flush=True)
				#print('Pi values1: ', Pi, flush=True)
			#print('Post subscribeVal SumMayRunON', SumMayRunON, flush = True)
			#printing data to test sorting:
			#print('Pi values2: ', Pi, flush=True)
			#print('P values2: ', P, flush=True)
			#print('Clear Price: ', calClearPrice(100,Pi), flush = True)
			#print('Pi_sorted values: ', Pi_sorted, flush=True)
		events = fncs.get_events()
		sumRealPower = [0 for i in range(24)]
		for key in events:
			#Global variables
			#P = []
			#Pi = []
			#P_sorted = []
			#Pi_sorted = []
			title = key.decode()
			value = fncs.get_value(key).decode()
			if title.startswith('RealPowerkWh'):
				#fncs.publish('LoadCheck',150)
				S = title.split('#')
				RealPowerkWh[S[1]]['real_power_kWh']= get_number(value)
				#print ('RealPowerkWh: ',RealPowerkWh[S[1]]['real_power_kWh'], flush = True)
				day = int(ts / day_len)# - ts % 2400 # day = 24*100s $ day_len = 2400s
				hour_float = ((ts - (day * day_len)) / hour_len)
				#print ('hour: ',hour_float, flush = True)
				hour = int(hour_float)
				if ts% hour_len == 0: # hour = 100s
					#print ('hour_float: ',hour_float, flush = True)
					#print ('ts: ',ts, flush = True)
					#print ('day: ',day, flush = True)
					#print ('hour: ',hour, flush = True)
					sumRealPower[hour] = sumRealPower[hour] + RealPowerkWh[S[1]]['real_power_kWh'] - RealPowerkWh[S[1]]['Prev_real_power_kWh']
					#print ('sumRealPower: ',sumRealPower[hour], flush = True)
					AvgsumRealPower[day][hour] = 1000 * sumRealPower[hour]/hour_len
					#print ('AvgsumRealPower: ',AvgsumRealPower[day][hour], flush = True)
					RealPowerkWh[S[1]]['Prev_real_power_kWh'] = RealPowerkWh[S[1]]['real_power_kWh']
				if ts % delTRP == 0: # needs to be modified
					for i in range(len(RealPowerkWh)):
						if ts!=0:
							#print ('checking energybillRevenue..', RealPowerkWh[S[1]]['energybillRevenue'], flush = True)
							#print ('checking energybillCost..', RealPowerkWh[S[1]]['energybillCost'], flush = True)
							RealPowerkWh[S[1]]['energybillRevenue'] = RealPowerkWh[S[1]]['energybillRevenue'] + RP[iter-1] * (RealPowerkWh[S[1]]['real_power_kWh'] - RealPowerkWh[S[1]]['Prev_real_power_kWh'])
							RealPowerkWh[S[1]]['energybillCost'] = RealPowerkWh[S[1]]['energybillCost'] + WPDAMModified[iter-1] * (RealPowerkWh[S[1]]['real_power_kWh'] - RealPowerkWh[S[1]]['Prev_real_power_kWh'])
							if ts % delTBreakeven == 0:
								sumenergybillRevenue = 0
								sumenergybillCost = 0
								for i in range(len(RealPowerkWh)):
									sumenergybillRevenue = sumenergybillRevenue + RealPowerkWh[S[1]]['energybillRevenue'] 
									sumenergybillCost = sumenergybillCost + RealPowerkWh[S[1]]['energybillCost'] 
								#print ('checking breakeven condition:',  )
								# if sumenergybillRevenue == sumenergybillCost:
									# #print ('breakeven condition:', flush = True)
									# pass
								# elif sumenergybillRevenue > sumenergybillCost:
									# #print ('sumenergybillRevenue > sumenergybillCost', flush = True)
									# pass
								# else:
									# #print ('sumenergybillRevenue < sumenergybillCost', flush = True)
									# pass
							iter += 1
							if iter > 24*60:
								iter = 1
							#RealPowerkWh[S[1]]['Prev_real_power_kWh'] = RealPowerkWh[S[1]]['real_power_kWh']
					#print('printing RP', RP[iter], flush = True) 
					if case == 1:
						publish_Price(RP[iter])
				#fncs.publish('ResetRealPower', 0)
			# if title == 'base_line':
				# value = float(fncs.get_value(key).decode())
				# base_line= value
				# print('base_line received: ', base_line, flush = True)

			if title == 'distribution_load':
				valuesplit = value.split(' ')
				valuedecoded = valuesplit[0]
				valuedecoded = valuedecoded.replace('i','j')
				#value = fncs.get_value(key).decode()
				#print('valuedecoded', valuedecoded,  flush=True)
				valuecomplex = complex(valuedecoded)
				#value = value.replace('VA', '')
				#print('valuecomplex', valuecomplex, flush=True)
				z = complex(valuecomplex)
				distribution_load = z.real
				#print('distribution_load received: ', distribution_load, flush = True)
				
			if title.startswith('tap'):
				if title == 'tapA':
					tapA = int(value)
				elif title == 'tapB':
					tapB = int(value)
				elif title == 'tapC':
					tapC = int(value)	
				#print('tapABC', tapA, tapB, tapC, flush = True)
			# price
			if title.startswith('Error'):
				ErrorSignalNew = 0
				#ErrorSignal = -Correction + float(value)
				#if ts % delTRP == 0:				
			if title.startswith('WPDAM'):
				#print('printing value vector ', value, flush = True)
				WPDAM = value.split(',')
				#print('printing WPDAM string', WPDAM, flush= True)
				#print('WPDAM string length', len(WPDAM), flush=True)
				#hardcoded instead of len(WPDAM)
				for i in range(24):
					#print(i, flush=True)
					WPDAM[i] = get_number(WPDAM[i])
				RP = [i for i in WPDAM for j in range(60)]
				WPDAMModified = [i for i in WPDAM for j in range(60)]
				print('Day-ahead LMP', WPDAM, flush = True)
				#print('printing RP vector ', RP, flush = True)
				#publish_Price(float(value))
			# if title.startswith('WPDAM'):
				# print('WPDAM:price',value,flush = True)
				# fncs.publish('WPDAM', value)
				#publish_WP(value)
			if title.startswith('WPRTM'):
				WPRTM = value
				print('RTM LMP', WPRTM, flush = True)
			if title.startswith('voltage'):
				if value.endswith('V'):
					#print('voltage val', value, flush = True)
					valuesplit = value.split(' ')
					valuedecoded = valuesplit[0]
					valuecomplex = complex(valuedecoded)
					absvalue = abs(valuecomplex)
					#print('Split: ', valuecomplex, absvalue, flush = True)			
				if title[-2:]=='AN':
					if len(voltage_listA)>0:
						for item in voltage_listA:
							if item[0]==title[-5:-2]:
								item[2] = absvalue
							else:
								voltage_listA.append([title[-5:-2], title[-2:], absvalue])
					else:
						voltage_listA.append([title[-5:-2], title[-2:], absvalue])
	#				node_listA.append()
				if title[-2:]=='BN':
					if len(voltage_listB)>0:
						for item in voltage_listB:
							if item[0]==title[-5:-2]:
								item[2] = absvalue
							else:
								voltage_listB.append([title[-5:-2], title[-2:], absvalue])
					else:
						voltage_listB.append([title[-5:-2], title[-2:], absvalue])						
				if title[-2:]=='CN':
					if len(voltage_listC)>0:
						for item in voltage_listC:
							if item[0]==title[-5:-2]:
								item[2] = absvalue
							else:
								voltage_listC.append([title[-5:-2], title[-2:], absvalue])
					else:
						voltage_listC.append([title[-5:-2], title[-2:], absvalue])
		
		if ts == 0:
			base_line = getfromcsv(0,0)
		
		if (ts % deltaT == 0 and ts !=0) :
			day = int(ts / day_len)# - ts % 2400 # day = 24*100s $ day_len = 2400s
			hour = int((ts - (day * day_len)) / hour_len)
			#print('day: ', day, flush = True)
			#print('hour: ', hour, flush = True)
			if day>1: # hour = 100s
				#print('printing AvgsumRealPower: ', AvgsumRealPower[day-2][hour], flush = True)
				base_line = AvgsumRealPower[day-2][hour]
			else:
				base_line = getfromcsv(day, hour)
			#print('printing base_line: ', base_line, flush = True)
			power_error = base_line - distribution_load
			hvac = SumMayRunON + SumMustON
			sub_time= sub_time+1
			#print('time:', ts, 'base_line:', base_line, 'distribution_load:', distribution_load, flush = True)
			ErrorSignalNew = power_error + SumMayRunON
			#print('time:', ts, 'power_error:', power_error, 'SumMayRunON:', SumMayRunON, 'ErrorSignalNew:', ErrorSignalNew, flush = True)
			Pi_Cleared, ErrorMet = calClearPrice(ErrorSignalNew, P, Pi, SumMayRunON)
			#print('ErrorMet', ErrorMet, flush = True)
			#print('sumMustON:', SumMustON, 'SumMayRunON:', SumMayRunON, 'hvac:', hvac, flush = True)
			d_loadNew = distribution_load + float(ErrorMet) - float(SumMayRunON)
			#print('d_loadNew', d_loadNew, flush = True)
			bline_append(base_line)
			dload_append(distribution_load)
			#Nhvac.appen()
			#print('Pi_sorted values: ', Pi_sorted, flush=True)
			#print('time', ts, 'clear_price: ', Pi_Cleared, flush = True)
			#print('Clear Price: ', Pi_Cleared, flush = True)
			#Pi_Cleared = 0
			if sub_time >=num_sub_intervals:
				sub_time=0
				if case == 2:
					publish_Price(Pi_Cleared)
					print('time:', ts, 'power_error:', power_error, 'Signal:', ErrorSignalNew, 'ClearedPrice CP:', Pi_Cleared, flush = True)
					clprice.extend([Pi_Cleared for i in range(num_sub_intervals)])
					clprice_temp = [Pi_Cleared for i in range(num_sub_intervals)]
					clprice_append(clprice_temp)
		
		#print('len bline', len(bline), flush = True)
		#print ('day: ',day, flush = True)
		#print ('hour: ',hour, flush = True)
		if ((day> 0 or (day ==0 and hour == 23)) and (ts%(hour_len)) == 0): # hour = 100s
			#print('day: ', day, 'hour: ', hour,flush = True)
			#print ('AvgsumRealPower1[day][hour]: ',AvgsumRealPower[day][hour], flush = True)
			loadforecast_RP([AvgsumRealPower[day][hour]], hour, day)
		if (day>0):
			if (ts%((day)*(day_len))) == 0:
				#print('day: ', day, 'hour: ', hour,flush = True)
				#print ('AvgsumRealPower[day]: ',AvgsumRealPower[day], flush = True)
				loadforecast_RP(AvgsumRealPower[day], hour, day)
		#print ('ts3: ',ts, flush = True)
		if(len(load)!=0):
			for i in range(len(load)):
				if(ts >= load[i][0]):
					if(ts == load[i][0]):
						#print('str(load[i][0]): ', str(load[i][0]),'str(load[i][1]): ', str(load[i][1]),'str(load[i][2]): ', str(load[i][2]), flush = True)
						fncs.publish(str(load[i][1]), load[i][2])
				else:
					break
		#print('tapABC', tapA, tapB, tapC, flush = True)
		Adjust_tap_A = check_voltage(voltage_listA)
		UpdateTapA = tapA + Adjust_tap_A	
		#print('Adjust TapA', Adjust_tap_A, 'Updated TapA', UpdateTapA, flush = True)
		fncs.publish('reg_statusTapA', UpdateTapA)
		Adjust_tap_B = check_voltage(voltage_listB)
		UpdateTapB = tapB + Adjust_tap_B	
		#print('Adjust TapB', Adjust_tap_B, 'Updated TapB', UpdateTapB, flush = True)
		fncs.publish('reg_statusTapB', UpdateTapB)	
		Adjust_tap_C = check_voltage(voltage_listC)
		UpdateTapC = tapC + Adjust_tap_C
		#print('Adjust TapC', Adjust_tap_C, 'Updated TapC', UpdateTapC, flush = True)
		voltage_listA=[]
		voltage_listB=[]
		voltage_listC=[]
		fncs.publish('reg_statusTapC', UpdateTapC)

	plotfn()
	print ('finalizing FNCS', flush=True)
	fncs.finalize()

