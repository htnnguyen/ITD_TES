import csv
import fncs
import sys
import json

from ramp_controller_objectNew import ramp_controller_objectNew

filename = sys.argv[1]
lp = open(filename).read()
controllerDict = json.loads(lp)

tf = 48 # simulation time in hours
deltaT = 300 #300  # simulation time interval in seconds, which usually the same as controller period 

# Create controller object:
controller_obj =  ramp_controller_objectNew(controllerDict)

time_granted = 0 # time variable for checking the returned time from FNCS
timeSim= 0


while (time_granted < tf*3600):
    # =================Simulation for each time step ============================================ 
    if time_granted != 0:
        fncs_sub_value_String = ''
        fncs_sub_value_unicode = (fncs.agentGetEvents()).decode()
        #print('printing all agent events', fncs.agentGetEvents())
        if fncs_sub_value_unicode != '':
            fncs_sub_value_String = json.loads(fncs_sub_value_unicode)
            print('time: ', time_granted, flush = True)
            controller_obj.subscribeVal(fncs_sub_value_String)
    if time_granted != 0:
        events = fncs.get_events()
        #print('printing all events', events, flush = True)
        for key in events:
            title = key.decode()
            value = fncs.get_value(key).decode()
            controller_obj.subscribeGLD(title,value)

    controller_obj.sync(time_granted)
    
    #print('time_granted::', time_granted, flush = True) 
    if (time_granted < (timeSim)) :
        time_granted = fncs.time_request(timeSim)
        #print('time_granted::', time_granted, flush = True) 
    else:
        timeSim = timeSim + deltaT
        time_granted = fncs.time_request(timeSim)
        
# finalize fncs
fncs.finalize()