
TestCase: IEEE 13 bus system with 180 houses(fig: Modified_IEEE13Bus_Testsystem.png)
==========================================================
1.	runAMES.bat  # To run ITD - both AMES and distribution system together
2.	runWithoutAMES.bat # To run only distribution system
