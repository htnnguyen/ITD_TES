from matplotlib import pyplot as plt
import math
import csv
import sys


f = open('base_line_generator.csv','r')
reader = csv.reader(f)
val = []
time = []

for line in reader:
	#if(line[0][0] != '#'):
	#time.append(line[0])
	val.append(float(line[0]))

#for i in range(0,len(val),12):
for i in range(0,len(val),60):
	sum = 0
	#print(i)
	for j in range(i,i+60):
		if(j<=len(val)-1):
			sum = sum + val[j]
	sum = sum/60
	val[i:i+60] = [sum for i in range(60)]

##For plotting:
#fig = plt.figure(1)
#plt.plot(range(len(val)),val)
#plt.show()

#Code to write base_line.txt:
old_stdout = sys.stdout

log_file = open("base_line.csv","w")

sys.stdout = log_file

#print ('#time	topic  value')

for i in range(len(val)):
	print(val[i])
sys.stdout = old_stdout
log_file.close()