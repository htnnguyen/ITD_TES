#	Copyright (C) 2017 Battelle Memorial Institute
import json
import sys
import warnings
import csv
import fncs
import math
import cmath
import re
import matplotlib.pyplot as plt
#from loadforecast import loadforecast_RP

price= 10
temp = [price for i in range(10)]
print(temp)
for i in range(len(temp)):
	print(temp[i], flush=True)

hour_factor = 120
bline = []
dload = []
f = open('base_line_intermediate.csv','r')
reader = csv.reader(f)
for line in reader:
	bline.append(float(line[0]))
f.close()

f = open('dload_intermediate.csv','r')
reader = csv.reader(f)
for line in reader:
	dload.append(float(line[0]))
f.close()

f = open('clprice_intermediate.csv','r')
reader = csv.reader(f)
for line in reader:
	clprice.append(float(line[0]))
f.close()

#prepare stick
ind =[ i for i in range(0,len(dload)+int(hour_factor),int(hour_factor))]
str_stick =[ str(int((i+0.00001)/hour_factor)) for i in ind]
#Plotting dload and bline
fig = plt.figure(1)
plt.subplot(211)
t = range(len(dload))
p1=plt.plot(t, dload, 'b', )
p2=plt.plot(t, bline, 'r', )
plt.xlabel("Time (h)")
plt.ylabel("Power (W)")
plt.xticks(ind,str_stick)
plt.subplot(212)
t2 = range(len(clprice))
p3=plt.plot(t2, clprice,)
plt.xlabel("Time (h)")
plt.ylabel("Price ($/kWh)")
plt.xticks(ind,str_stick)
plt.legend((p1[0], p2[0], p3[0]), ('Actual Household Load (Price Controlled)', 'Target Load','Price Signal'))
#plt.grid(True)
plt.show()