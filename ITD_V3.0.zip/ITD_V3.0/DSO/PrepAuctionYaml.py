import sys
import yaml


HouseNo = 12 # 24 for 360 houses
Node = 15
TotalHouses = Node * HouseNo

data = {}
data['name'] = 'auction_Market_1'
data['time_delta'] = '1s'
data['broker'] = 'tcp://localhost:5570'
data['values'] = {}
data['values']['distribution_load'] = {'topic': 'gridlabdSimulator1/distribution_load', 'default': 0.0}
data['values']['distribution_energy'] = {'topic': 'gridlabdSimulator1/distribution_energy', 'default': 0.0}
data['values']['WPDAM'] = {'topic': 'ames/DailyLMP', 'default': 1}
data['values']['WPRTM'] = {'topic': 'ames/RTLMP', 'default': 1}

for i in range(Node):
    for j in range(HouseNo):
        housename = 'house_'+str(i+1)+'_'+str(j+1)+'_thermostat_controller'
        details = {'topic':'controller_house_'+str(i+1)+'_'+str(j+1)+'_thermostat_controller/TransactiveAgentOutput', 'default': {"controller":{"house_"+str(i+1)+'_'+str(j+1):{"bid_id":{"propertyType":"string","propertyUnit":"none","propertyValue":0},"market_id":{"propertyType":"integer","propertyUnit":"none","propertyValue":0},"price":{"propertyType":"double","propertyUnit":"none","propertyValue":0.0},"quantity":{"propertyType":"double","propertyUnit":"none","propertyValue":0.0},"rebid":{"propertyType":"integer","propertyUnit":"none","propertyValue":0},"state":{"propertyType":"string","propertyUnit":"none","propertyValue":"ON"},"air_temperature": {"propertyType": "double", "propertyUnit": "none", "propertyValue": 0.0}}}}}
        #d = {housename:details}
        data['values']['RealPowerkWh#house_'+str(i+1)+'_'+str(j+1)] = {'topic' : 'gridlabdSimulator1/house_'+str(i+1)+'_'+str(j+1)+'/realPowerkWh', 'default' : 0.0}
        data['values'][housename] = details

with open('auction.yaml', 'w') as outfile:
    yaml.dump(data, outfile, default_flow_style=False)