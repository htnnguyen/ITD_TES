import warnings
import sys
import json
import fncs

# Class definition
class ramp_controller_object:

	# ====================Define instance variables ===================================
	def __init__(self, controllerDict):
		# Obtain the registration data and initial values data
		agentRegistration = controllerDict['registration']
		agentInitialVal = controllerDict['initial_values']

		# Hardcoded the max day value, generalise later
		self.dayMax = 5
		
		# Initialize the variables
		self.market = { 'retail_price': -1}
		self.house = {'deadband': 0, 'currTemp': -1, 'prevTemp': -1, 'houseType': 'Unknown', 'thermostatcontrol': 'UNKNOWN', 'systemmode': 'UNKNOWN', 'last_systemmode': 'UNKNOWN', 'Tbliss': 0, 'd': 1, 'theta': 1, 'P': 1, 'P_ON': 1}
		self.controller = {'name': 'none', 'marketName': 'none', 'houseName': 'none', 'simple_mode': 'none', 'setpoint': 'none', 'lastbid_id': -1, 'lastmkt_id': -1, 'bid_id': 'none', 'deadband': 0, 'period': -1, 'last_q': 0, 'setpoint0': -1, 'minT': 0, 'maxT': 0, 'bid_delay': 60, 'next_run': 0, 't1': 0, 't2': 0, 'sliding_time_delay': -1, 'thermostat_mode': 'INVALID',  'last_mode': 'INVALID', 'previous_mode': 'INVALID', 'time_off': sys.maxsize}
		self.controller_bid = {'market_id': -1, 'bid_id': 'none', 'bid_price': 0.0, 'bid_quantity': 0, 'bid_accepted': 1, 'state': 'UNKNOWN', 'rebid': 0}
		self.controller['name'] = agentRegistration['agentName']

		# Read and assign initial values from agentInitialVal
		# controller information
		self.controller['marketName'] = agentInitialVal['controller_information']['marketName']
		self.controller['houseName'] = agentInitialVal['controller_information']['houseName']

		# market information - Market registration information
		self.market['name'] = self.controller['marketName']
		self.market['retail_price'] = 0 #agentInitialVal['market_information']['retail_price']

		# house information  - values will be given after the first time step, thereforely here set as default zero values
		self.house['currTemp'] = 78
		self.house['prevTemp'] = 78
		self.house['powerstate'] = "ON"
		self.house['controlled_load_all'] = 0
		self.house['target'] = "air_temperature"
		self.house['deadband'] = 2
		self.house['setpoint0'] = 0
		self.house['lastsetpoint0'] = self.house['setpoint0']

		self.house['thermostatcontrol'] = "NONE"
		self.house['systemmode'] = "COOL"
		self.house['last_systemmode'] = self.house['systemmode']
		# from auctionDict initial_values
		self.house['Tbliss'] = agentInitialVal['house_information']['Tbliss']
		self.house['d'] = agentInitialVal['house_information']['d']
		self.house['theta'] = agentInitialVal['house_information']['theta']
		self.house['P'] = 3 #agentInitialVal['house_information']['P']
		self.house['P_ON'] = 3 #agentInitialVal['house_information']['P']
		self.house['houseType'] = agentInitialVal['house_information']['houseType']
		
		#Overwriting initialized value
		self.house['theta'] = 10000
		
		#Overall welfare parameters:
		self.house['welfareparams'] = {}
		for i in range(self.dayMax):
			self.house['welfareparams'][i] = {'theta': self.house['theta'], 'lumpsum' : 0.0, 'EC':[], 'Discomfort':[]} #welfare parameters
		self.house['welfareparams'][0]['theta'] = self.house['theta']
		self.house['alpha'] = 1
		self.house['GMax'] = 1.5 #G Max
		self.house['G'] = 0.0
		self.house['welfare'] = 0.0
		self.house['temperature_previnterval'] = 78 # Temperature in the previous interval, interval = 5 min
		self.house['UA'] = 1.1 # Ua
		self.house['solar_gain'] = 1.1 # Qs
		self.house['heat_cool_gain'] = 1.1 # Qh
		self.house['mass_heat_coeff'] = 1.1 # Hm
		self.house['air_heat_capacity'] = 1.1 # Ca
		self.house['cooling_COP'] = 1.1 # COP
		self.house['k'] = 1 #3.413 # todo # replace with 1
		self.house['mass_temperature'] = 78 # TMo
		self.house['outdoor_temperature'] = 1.1
		self.house['mass_temperature'] = 1.1
		self.h = 0.04
		self.h2 = self.h/2
		self.M1 = 0.0
		self.M2 = 0.0
		self.M3 = 0.0
		self.PiStar = 0.0
		
		self.day = 0
		self.hour = 0
		self.minute = 0
		self.prevday = 0
		self.prevhour = 0
		self.prevminute = 0
		
		
		# Generate agent publication dictionary
		self.fncs_publish = {
		'controller': {
		self.controller['name']: {
		'price': {'propertyType': 'double', 'propertyUnit': '', 'propertyValue': 0.0},
		'quantity': {'propertyType': 'double', 'propertyUnit': '', 'propertyValue': 0.0},
		'P_ON': {'propertyType': 'double', 'propertyUnit': '', 'propertyValue': 0.0},
		'state': {'propertyType': 'string', 'propertyUnit': '', 'propertyValue': 'BS_UNKNOWN'},
		'air_temperature': {'propertyType': 'double', 'propertyUnit': '', 'propertyValue': 78}
		}
		}
		}
		# Registrate the agent
		agentRegistrationString = json.dumps(agentRegistration)
		self.fncs_publish['controller'][self.controller['name']]['air_temperature'] = self.house['currTemp']
		fncs.agentRegister(agentRegistrationString.encode('utf-8'))
		print('agent registration is done', flush = True)

	# ====================extract float from string ===============================
	def get_num(self,fncs_string):
		return float(''.join(ele for ele in fncs_string if ele.isdigit() or ele == '.'))

	def get_number(self,value):
		#print('value:', value, flush=True)
		return float(''.join(ele for ele in value if ele.isdigit() or ele == '.'))

	# ====================Obtain values from the broker ===========================
	def subscribeGLD(self, title, value,time_granted):
		if title.startswith('air_temperature'):
			self.house['currTemp'] = self.get_number(value)
			self.fncs_publish['controller'][self.controller['name']]['air_temperature'] = self.house['currTemp']
		if title.startswith('hvac_load'):
			self.house['P'] = self.get_number(value)
			self.house['systemmode'] = "OFF"
			if self.get_number(value)!=0:
				self.house['systemmode'] = "COOL"
				self.house['P_ON'] = self.get_number(value)
		if title.startswith('costperinterval'):
			self.house['welfareparams'][self.prevday]['EC'].append(self.get_number(value))
			temp = 0.5 * ((self.house['prevTemp'] - self.house['Tbliss'])**2 + (self.house['currTemp'] - self.house['Tbliss'])**2)
			self.house['welfareparams'][self.prevday]['Discomfort'].append(temp)
			#self.house['G'] = self.house['GMax'] - self.h/2 * ((self.house['temperature_previnterval'] - self.house['Tbliss'])**2 + (self.house['currTemp'] - self.house['Tbliss'])**2)
			#self.house['welfare'] = self.house['G'] - self.house['alpha'] * self.house['EC']
			self.house['temperature_previnterval'] = self.house['currTemp']
		if title.startswith('lumpsum'):
			self.house['welfareparams'][self.prevday]['lumpsum'] = self.get_number(value)
			#print('self.house[welfareparams][self.prevday][lumpsum]:', self.house['welfareparams'][self.prevday]['lumpsum'], flush=True)

	# ====================Obtain values from the broker ===========================
	def subscribeVal(self, fncs_sub_value_String,time_granted):

		# Update market and house information at this time step from subscribed key values:
		retail_price = self.market['retail_price']
		systemmode = self.house['systemmode']
		air_temperature = self.house['prevTemp']
		Tbliss = self.house['Tbliss']
		d = self.house['d']
		
		if "auction" in fncs_sub_value_String:
			#print('auction: time Val 2:', time_granted, 'prevTemp: ', air_temperature, 'currTemp', self.house['currTemp'], flush=True)
			self.market['retail_price'] = fncs_sub_value_String['auction'][self.market['name']]['retail_price']
			pistar = self.house['theta'] * (air_temperature - Tbliss)/d
			retail_price = self.market['retail_price']
			print('pi*', pistar, 'CP', retail_price, flush = True)
			if air_temperature >= Tbliss + d:
				print('air_temperature exceeded Tmax: setting Cool ON for the house', flush=True)
				systemmode = "COOL"
				self.fncs_publish['controller'][self.controller['name']]['state'] = "COOL"
			elif Tbliss - d >= air_temperature:
				print('air_temperature is below Tmin: setting Cool OFF for the house', flush = True)
				systemmode = "OFF"
				self.fncs_publish['controller'][self.controller['name']]['state'] = "OFF"
			elif retail_price > pistar:
				print('pi* is below retail_price: setting Cool OFF for the house', flush = True)
				systemmode = "OFF"
				self.fncs_publish['controller'][self.controller['name']]['state'] = "OFF"
			else:
				print('pi* is above retail_price: setting Cool ON for the house', flush = True)
				systemmode = "COOL"
				self.fncs_publish['controller'][self.controller['name']]['state'] = "COOL"
			#self.fncs_publish['controller'][self.controller['name']]['state'] = "COOL"
			#systemmode = "COOL"
			self.house['systemmode'] = systemmode
			fncs.publish('system_mode', systemmode)

	def jsonvaldump(self):
		s = './jsonfiles/welfareparameters#' + self.controller['houseName'] + '#day_' + str(self.prevday) + '.json'
		outfile = open(s, 'w') 
		#json.dump(json_data, outfile)
		json.dump(self.house['welfareparams'][self.prevday], outfile)
		return None

	def clearmemory(self):
		self.house['welfareparams'][self.prevday]['EC'] = []
		self.house['welfareparams'][self.prevday]['Discomfort'] = []
		return None

	# ====================Rearrange object based on given initial values======================
	def initController(self):
		# Update controller bidding period:
		if self.controller['period'] == 0.0:
			self.controller['period'] = 300


	# ==================================Sync content===========================
	def sync(self, time_granted):

		#print('time sync:', time_granted, 'prevTemp: ', self.house['prevTemp'], flush=True)
		self.house['prevTemp'] = self.house['currTemp']
		#print('time sync:', time_granted, 'currTemp: ', self.house['currTemp'], flush=True)

		if self.fncs_publish['controller'][self.controller['name']]['state'] == "COOL":
			self.fncs_publish['controller'][self.controller['name']]['quantity'] = self.house['P']
		else:
			self.fncs_publish['controller'][self.controller['name']]['quantity'] = 0

		self.fncs_publish['controller'][self.controller['name']]['P_ON'] = self.house['P_ON']

		#print('publishing set values', flush = True)
		fncs_publishString = json.dumps(self.fncs_publish)
		fncs.agentPublish(fncs_publishString)