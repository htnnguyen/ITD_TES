'''
main file of the controller object, mainly used for assigning data read from input
'''
 
# import from library or functions
#import numpy as np
import csv
import fncs
import sys
import json

from ramp_controller_object import ramp_controller_object

# ==================Generate agent registration information ==================================
# This is similar to a zpl file, for assigning initial values to the agent
# If it is ramp controller:
# Read in json file with the controller registration data
filename = sys.argv[1]
tmax = int(sys.argv[2]) # simulation time in s
lp = open(filename).read()
controllerDict = json.loads(lp)

# ====================Initialize simulation time step and duration===============   
deltaT = 300 #300  # simulation time interval in seconds, which usually the same as controller period 
min_len = 60 # in s
hour_len = 3600 #100 # in s
day_len = 24* hour_len # in s
# ====================Obtain controller bid====================================

# Create controller object:
controller_obj =  ramp_controller_object(controllerDict)

time_granted = 0 # time variable for checking the retuned time from FNCS
timeSim= 0

# Start simulation for each time step:
while (time_granted < tmax):
	# =================Simulation for each time step ============================================ 
	#print('time_granted::', time_granted, flush = True) 
	controller_obj.day = int(time_granted / day_len)# - ts % 2400 # day = 24*100s $ day_len = 2400s
	controller_obj.hour = int((time_granted - (controller_obj.day * day_len)) / hour_len)
	controller_obj.minute = int((time_granted - (controller_obj.day * day_len) - controller_obj.hour * hour_len)/60)

	# Initialization when time = 0
	if time_granted == 0:
		controller_obj.initController()

	# Subscrib values from FNCS broker (or csv file here)
	if time_granted != 0:
		fncs_sub_value_String = ''
		fncs_sub_value_unicode = (fncs.agentGetEvents()).decode()
		#print('printing all agent events', fncs.agentGetEvents())
		if fncs_sub_value_unicode != '':
			fncs_sub_value_String = json.loads(fncs_sub_value_unicode)
			#print('fncs_sub_value_String: ', fncs_sub_value_String, flush = True)
			controller_obj.subscribeVal(fncs_sub_value_String,time_granted)

	#Subscribe values from GLD
	if time_granted != 0:
		events = fncs.get_events()
		#print('printing all events', events, flush = True)
		for key in events:
			title = key.decode()
			value = fncs.get_value(key).decode()
			controller_obj.subscribeGLD(title,value,time_granted)

	# Sync process
	controller_obj.sync(time_granted)

	# Dump data into json file
	if controller_obj.day != controller_obj.prevday:
		if controller_obj.day > 2:
			# if controller_obj.hour == 1 and controller_obj.day > 1:
			controller_obj.jsonvaldump()
			#controller_obj.clearmemory()

	# Advancing time and updating day, hour and minute:
	if (time_granted < (timeSim)) :
		time_granted = fncs.time_request(timeSim)
		#print('time_granted::', time_granted, flush = True) 
	else:
		timeSim = timeSim + deltaT
		time_granted = fncs.time_request(timeSim)
		controller_obj.day = int(time_granted / day_len)# - ts % 2400 # day = 24*100s $ day_len = 2400s
		controller_obj.hour = int((time_granted - (controller_obj.day * day_len)) / hour_len)
		controller_obj.minute = int((time_granted - (controller_obj.day * day_len) - controller_obj.hour * hour_len)/60)
	
	controller_obj.prevday = controller_obj.day
	controller_obj.prevhour = controller_obj.hour
	controller_obj.prevminute = controller_obj.minute
	#print('************************************************', flush=True)

# finalize fncs
fncs.finalize()