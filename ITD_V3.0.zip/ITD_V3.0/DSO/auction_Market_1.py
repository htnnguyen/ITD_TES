#	Copyright (C) 2017 Battelle Memorial Institute
import json
import sys
import warnings
import csv
import fncs
import math
import cmath
import re
#import matplotlib.pyplot as plt
#from loadforecast import loadforecast_RP

def initAuction(auctionDict):
	agentRegistration = auctionDict['registration']
	agentInitialVal = auctionDict['initial_values']
	#print('Market Name', agentRegistration['agentName'], market['name'], flush = True)
	market['name'] = agentRegistration['agentName']
	print('Market Name', agentRegistration['agentName'], market['name'], flush = True)
	# Read and assign initial values from agentInitialVal
	# Controller information
	controller['name'] = agentInitialVal['controller_information']['name']
	controller['price'] = agentInitialVal['controller_information']['price']
	controller['quantity'] = agentInitialVal['controller_information']['quantity']
	controller['state'] = agentInitialVal['controller_information']['state']
	#print('check Tbliss:', agentInitialVal['controller_information']['Tbliss'], flush = True)
	controller['Tbliss'] = agentInitialVal['controller_information']['Tbliss']
	controller['d'] = agentInitialVal['controller_information']['d']
	controller['theta'] = agentInitialVal['controller_information']['theta']
	controller['P'] = agentInitialVal['controller_information']['P']
	controller['houseType'] = agentInitialVal['controller_information']['houseType']
	controller['air_temperature'] = agentInitialVal['controller_information']['air_temperature']
	
	for i in range(0,len(agentInitialVal)):
		s = agentInitialVal['controller_information']['name'][i]
		#print('s', s, flush = True)
		housedata['name'] = s
		housedata['price'] = agentInitialVal['controller_information']['price'][i]
		housedata['quantity'] = agentInitialVal['controller_information']['quantity'][i]
		housedata['state'] = agentInitialVal['controller_information']['state'][i]
		housedata['Tbliss'] = agentInitialVal['controller_information']['Tbliss'][i]
		housedata['d'] = agentInitialVal['controller_information']['d'][i]
		housedata['theta'] = agentInitialVal['controller_information']['theta'][i]
		housedata['P'] = agentInitialVal['controller_information']['P'][i]
		housedata['houseType'] = agentInitialVal['controller_information']['houseType'][i]
		housedata['air_temperature'] = agentInitialVal['controller_information']['air_temperature'][i]
		housedataArray.append(housedata)
	
	return 0

load = []
min_len = 60 # in s
hour_len = 3600 #100 # in s
day_len = 24* hour_len # in s

def loadforecast_DAM(loadforecast, h, d):
	time = []
	loadforecastRTM = [[] for i in range(3)]
	loadforecastDAM = []
	unit = 1 #1000000000

	#24 hour vector -> DAM
	if(len(loadforecast) > 1):
		x = (d* day_len)*unit + ((hour_len)/2)*unit - 1*unit
		for j in range(24):
			load.append((x,'loadforecastDAM_h'+str(j), float(loadforecast[j])*1)) # replace 1 with
	return None

# extract float from string
def get_number(value):
	return float(''.join(ele for ele in value if ele.isdigit() or ele == '.'))

def get_number_ames(value):
	for char in value:
		if char in "'":
			value.replace(char,'')
	#print("value is ",value,flush=True)
	return get_number(value)


def subscribeValHVAC(fncs_sub_value_String, Correction, ts):
	# Assign values to buyers
	P = []
	Pi = []
	SumMustON = 0
	SumMayRunON = 0
	SumMayRunOFF = 0
	#Pi_all = []
	controllerKeys = list (fncs_sub_value_String['controller'].keys())
	#print('checking controllerKeys length', len(controllerKeys), flush = True)
	print('time_grantedHVAC: ', ts, flush = True)
	for i in range(len(controllerKeys)):
		for j in range(len(controller['name'])):
			if controller['name'][j] == controllerKeys[i]:
				Tbliss_val = controller['Tbliss'][j]
				d_val = controller['d'][j]
				theta_val = controller['theta'][j]
				Ta_val = fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature']
				#S = controller['name'][j].split('_thermostat_controller')
				P_val = fncs_sub_value_String['controller'][controllerKeys[i]]['quantity'] * 1000
				PAvg_val = fncs_sub_value_String['controller'][controllerKeys[i]]['P_ON'] * 1000
				if Ta_val >= Tbliss_val + d_val:
					Correction = Correction + P_val
					SumMustON = SumMustON + P_val
				if Tbliss_val < Ta_val and Ta_val < Tbliss_val + d_val:
					#Pi_all.append(controller['theta'][j] * fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature'])
					if fncs_sub_value_String['controller'][controllerKeys[i]]['state'] == 'COOL':
						SumMayRunON = SumMayRunON + P_val
						controller['air_temperature'][j] = fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature']
						PiStar = theta_val * (Ta_val - Tbliss_val)/d_val
						Pi.append(PiStar)
						P.append(PAvg_val)
					else:
						SumMayRunOFF = SumMayRunOFF + P_val
						controller['air_temperature'][j] = fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature']
						PiStar = theta_val * (Ta_val - Tbliss_val)/d_val
						Pi.append(PiStar)
						P.append(PAvg_val)
				elif Tbliss_val - d_val < Ta_val and Ta_val < Tbliss_val:
					#Pi_all.append(controller['theta'][j] * fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature'])
					if fncs_sub_value_String['controller'][controllerKeys[i]]['state'] == 'COOL':
						SumMayRunON = SumMayRunON + P_val
						controller['air_temperature'][j] = fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature']
						PiStar = theta_val * (Ta_val - Tbliss_val)/d_val
						Pi.append(PiStar)
						P.append(PAvg_val)
					else:
						SumMayRunOFF = SumMayRunOFF + P_val
						controller['air_temperature'][j] = fncs_sub_value_String['controller'][controllerKeys[i]]['air_temperature']
						PiStar = theta_val * (Ta_val - Tbliss_val)/d_val
						Pi.append(PiStar)
						P.append(PAvg_val)
	return Correction, P, Pi, SumMayRunON, SumMayRunOFF, SumMustON

def calc_retail_price(error, P, Pi, SumMayRunON):
	#print('printing Pi list:', Pi, flush = True)
	sum = 0
	ErrorMet = 0
	#[Pi_sorted, indexlist] = sort_prices(Pi)
	P_sorted = []
	Pi_sorted = []
	indexlist = []
	sortedlist = sorted(enumerate(Pi), key = lambda x: x[1])
	sortedlist_reverse = sorted(sortedlist, key = lambda x: x[1], reverse = True)
	#print('printing sorted list:', sortedlist, flush = True)
	#print('printing sorted_reverse list:', sortedlist_reverse, flush = True)
	for i in sortedlist_reverse:
		indexlist.append(i[0])
		Pi_sorted.append(i[1])
	#print('printing index list:', indexlist, flush = True)
	# if len(Pi_sorted) > 0:
		# print('printing Pi_sorted list:', Pi_sorted, flush = True)
	for i in range(len(indexlist)):
		P_sorted.append(P[indexlist[i]])
	#print('printing P_sorted list:', P_sorted, flush = True)
	#print('printing length Pi_sorted:', len(Pi_sorted), flush = True)
	CP = 1.0
	if error <= 0:
		if len(Pi_sorted) > 0:
			CP = Pi_sorted[0] + 0.01
			#print('CP1:', CP, flush = True)
			# for i in range(len(P_sorted)):
				# ErrorMet = -1 * SumMayRunON
			ErrorMet = 0
		else:
			CP = 1.0
			print('CP2:', CP, flush = True)
			ErrorMet = 0
	elif error >0:
		if len(Pi_sorted) > 0:
			CP = Pi_sorted[0] + 0.01
			#print('CP3:', CP, flush = True)
			for i in range(len(P_sorted)):
				diff1 = abs(sum - error)
				ErrorMet = sum
				sum = sum + P_sorted[i]
				#print('printing sum:', sum, error, flush = True)
				#print('printing current Pi_sorted[i]:', Pi_sorted[i], flush = True)
				diff2 = abs(sum - error)
				if sum >= error:
					if diff1 > diff2:
						ErrorMet = sum
						CP = Pi_sorted[i]
					if CP > 1:
						CP = 1
					if CP < -1:
						CP = -1
					#print('printing4 ErrorSignalNew, ErrorMet', error, ErrorMet, flush = True)
					#print('CP4:', CP, flush = True)
					return CP, ErrorMet
				CP = Pi_sorted[i]
				#print('printing prev Pi_sorted[i]:', CP, flush = True)
		else:
			CP = 1.0
			#print('CP5:', CP, flush = True)
	# if CP > 1:
		# CP = 1
	# if CP < -1:
		# CP = -1
	#print('printing ErrorSignalNew, ErrorMet', error, ErrorMet, flush = True)
	#print('CP:', CP, flush = True)
	# power=P
	# price=Pi
	# price = sorted(price)  #sorted price (increasing order)
	# sort_index=sorted(range(len(price)), key=lambda k: price[k])
	# #create the aggregated power curve
	# power = [ power[i] for i in sort_index]
	# acc_power=power;
	# for i in range(len(price)):
		# acc_power[i]=math.fsum(power[i:])
	# # sum = 0
	# # for i in range(len(P_sort)):
		# # sum = 0
		# # for j in range(len(P_sort)-i):
			# # sum = sum +P_sort[i+j]
		# # acc_power[i]=sum
	# new_hvac_load = error
	# index = min(range(len(acc_power)), key=lambda i: abs(acc_power[i]-new_hvac_load))
	# CP = price[index]
	return CP, ErrorMet

def checkbreakeven(day):
	sumenergybillRevenue = 0
	sumenergybillCost = 0
	for j in range(len(RealPowerkWh)):
		sumenergybillRevenue = sumenergybillRevenue + RealPowerkWh[house_names[j]]['energybillRevenue']
		#sumenergybillCost = sumenergybillCost + RealPowerkWh[house_names[j]]['energybillCost']
	sumenergybillCost = DSO['energybillCost']
	val = 0.0
	print ('checking breakeven condition: sumenergybillRevenue and sumenergybillCost:', sumenergybillRevenue, sumenergybillCost, flush = True)
	if sumenergybillRevenue == sumenergybillCost:
		val = 0.0
		print ('DSO breaks even', flush = True)
	elif sumenergybillRevenue > sumenergybillCost:
		val = sumenergybillRevenue - sumenergybillCost
		print ('sumenergybillRevenue > sumenergybillCost', flush = True)
	else:
		val = sumenergybillRevenue - sumenergybillCost
		print ('sumenergybillRevenue < sumenergybillCost', flush = True)
	print ('NetRevenue:', val, flush = True) # in cents
	#Resetting values:
	DSO['energybillCost'] = 0.0
	for j in range(len(RealPowerkWh)):
		RealPowerkWh[house_names[j]]['energybillRevenue'] = 0.0
	return allocate_prices(val, day)

def allocate_prices(val, day):
	totalpowerconsumed = sum(AvgsumRealPower[day-1])
	b = [float(RealPowerkWh[house_names[i]]['Powerfinalval'] - RealPowerkWh[house_names[i]]['Powerinitval'])/totalpowerconsumed for i in range(len(RealPowerkWh))]
	for i in range(len(RealPowerkWh)):
		print ('lumpsum for house ', i, ':', val*b[i], flush = True)
		fncs.publish(house_names[i]+'/lumpsum', val*b[i])
	return None

#def publish_publications(value, mode, index):
def publish_Price(value):

	fncs_publish['auction'][market['name']]['retail_price'] = value
	fncs_publishString = json.dumps(fncs_publish)
	fncs.agentPublish(fncs_publishString)

	#fncs.publish('retail_price', value)
	# for i in range(15):
		# for j in range(12):
			# fncs.publish('retail_price'+'_'+'house_'+str(i+1)+'_'+str(j+1), value)
	return 0

def getfromcsv(day, hour):
	f = open('base_line_GLD.csv','r')
	reader = csv.reader(f)
	for i, line in enumerate(reader):
		if i == 24*60*day + 60*hour:
			#print('day:', day, 'hour:', hour, 'base_line:', float(line[0]), flush = True)
			return float(line[0])


tapA = 0
tapB = 0
tapC = 0
voltage_listA=[]
voltage_listB=[]
voltage_listC=[]
distribution_load = 600000
power_listA=[]
power_listB=[]
power_listC=[]
energy_listA = []
energy_listQ = []
WPDAM = [0.0 for i in range(24)]
delTRP = 300
deltaT = 1#30  # simulation time interval in seconds(minutes), which usually the same as controller period
samplingtime = 30
hour_factor = 3600/(samplingtime)
num_sub_intervals = int(300/deltaT)
dload = []
bline = []
clprice = []
delTAuction = 1
delTBreakeven = 300 #86400
CostIncurred24Hr = 0.0
Correction = 0
sub_time=0
SumMustON = 0
SumMayRunON = 0
SumMayRunOFF = 0
day = 0
hour = 0
prev_minute = 0
prev_hour = 0
prev_day = 0
flag = 1
denergy_prev = 0
denergy = 0
DSO={}
DSO['energybillCost'] = 0.0
m_factor = 0
RealPower = {}

timeSim = 0
MonthlyBill = 20
ts = 0
tnextBill = 300
dtBill = 300 #2592000

# temporary input for RTM:
#RET = [25.3401,24.1268,23.2716,15.7323,15.5858,15.6524,15.7992,23.7442,25.7337,27.3299,27.7305,27.9273,27.7305,27.3299,27.1331,27.1331,27.9273,29.7203,28.9258,28.7218,28.5252,28.1244,27.1331,25.9378]
market = {'name': 'none',' period': -1, 'market_id': 1}
controller = {'name': [], 'price': [], 'quantity': [], 'state': [], 'Tbliss': [], 'd': [], 'theta': [], 'P': [], 'houseType': [], 'air_temperature': []}
housedata = {'name': 'none', 'air_temperature': 78, 'state': 'ON', 'Tbliss': 75, 'd': 10, 'theta': 1.0, 'P': 2.1, 'houseType': 'none', 'price': 0.0, 'quantity': 0.0}
housedataArray = []
PControlSignal = 10
RealPowerkWh = {}
house_names = []

json_data = {}
json_data['RETPrice'] = []
json_data['dload'] = []
json_data['bline'] = []

if len(sys.argv) == 7:
	filename = sys.argv[1]
	rootname = sys.argv[2]
	StartTime = sys.argv[3]
	tmax = int(sys.argv[4])
	dt = int(sys.argv[5])
	case = int(sys.argv[6])
elif len(sys.argv) == 1:
	rootname = 'ppcase'
	StartTime = "2013-07-01 00:00:00"
	dt = 3600
	tmax = 2 * 24 * 3600
	case = 1
else:
	print ('usage: python fncsPYPOWER.py [rootname StartTime tmax dt]')
	sys.exit()

AvgsumRealPower = [[0 for i in range(24)] for j in range(int(tmax/(24*3600)+1))]
#const_cost = [[0.0 for i in range(24)] for j in range(int(tmax/day_len))]
#variable_cost = [[0.0 for i in range(24)] for j in range(int(tmax/day_len))]
RT = [[0.0 for i in range(24*60)] for i in range(int(tmax/day_len)+1)]
RET = [[25 for i in range(24*60)] for i in range(int(tmax/day_len)+1)]
sumRealPower = [0 for i in range(24)]
Pi_Cleared = 25
lp = open(filename).read()
auctionDict = json.loads(lp)
initAuction(auctionDict)

for i in range(len(controller['name'])):
	S = controller['name'][i].split('_thermostat_controller')
	RealPowerkWh[S[0]] = {'real_power_kWh' : 0.0, 'energybillRevenue': 0.0, 'Prev_real_power_kWh' : 0.0, 'energybillCost': 0.0, 'costperinterval': 0.0, 'Powerfinalval': 0.0, 'Powerinitval': 0.0} #costperinterval = [0.0 for i in range(12*24)]
	house_names.append(S[0])
#print('Realpowerkwhhouse: ', RealPowerkWh, flush=True)

# Generate agent publication dictionary
fncs_publish = {'auction': { market['name']: { 'retail_price': {'propertyType': 'double', 'propertyUnit': 'none', 'propertyValue': 0.0}}}}
fncs_publish['auction'][market['name']]['retail_price'] = 0.002
fncs.publish('retail_price', 0.002)
fncs.initialize()


with warnings.catch_warnings():
	warnings.simplefilter("ignore") # TODO - pypower is using NumPy doubles for integer indices
	#warnings.filterwarnings("ignore",category=DeprecationWarning)
	while ts <= tmax:
		#print ('time_granted1: ',ts, flush = True)
		
		day = int(ts / day_len)# - ts % 2400 # day = 24*100s $ day_len = 2400s
		hour = int((ts - (day * day_len)) / hour_len)
		minute = ((ts - (day * day_len) - hour * hour_len)/min_len)
		
		fncs_sub_value_unicode = (fncs.agentGetEvents()).decode()
		if fncs_sub_value_unicode != '':
			Correction = 0
			fncs_sub_value_String = json.loads(fncs_sub_value_unicode)
			if "controller" in fncs_sub_value_String:
				#print('Entered subscribeVal if loop', flush = True)
				Correction, P, Pi, SumMayRunON, SumMayRunOFF, SumMustON = subscribeValHVAC(fncs_sub_value_String, Correction, ts)
		events = fncs.get_events()
		
		#Receiving messages
		for key in events:
			title = key.decode()
			value = fncs.get_value(key).decode()
			if title.startswith('RealPowerkWh'):
				#print('RealPowerkWh:', title,'value: ', value, flush = True)
				S = title.split('#')
				RealPowerkWh[S[1]]['real_power_kWh']= get_number(value) / 1000 # converting Wh to kWh
				if flag == 1:
					RealPowerkWh[S[1]]['Prev_real_power_kWh'] = RealPowerkWh[S[1]]['real_power_kWh']
					flag = 0

			if title == 'distribution_load':
				valuesplit = value.split(' ')
				valuedecoded = valuesplit[0]
				valuedecoded = valuedecoded.replace('i','j')
				#value = fncs.get_value(key).decode()
				#print('valuedecoded', valuedecoded,  flush=True)
				valuecomplex = complex(valuedecoded)
				#value = value.replace('VA', '')
				#print('valuecomplex', valuecomplex, flush=True)
				z = complex(valuecomplex)
				distribution_load = z.real
				#print('time_granted1 DL:', ts,'distribution_load: ', distribution_load, flush = True)

			if title.startswith('WPDAM'):
				#print('printing value vector ', value, flush = True)
				WPDAM_temp = value.split(',')
				#hardcoded instead of len(WPDAM)
				for i in range(24):
					WPDAM[i] = get_number(WPDAM_temp[i])
				print('ts_dam: ',ts, 'printing WPDAM: ', WPDAM, flush = True)
			
			if title.startswith('WPRTM'):
				WPRTM = get_number(value)
				print('ts_rtm: ',ts, 'printing WPRTM: ', WPRTM, flush = True)
		
			if title.startswith('distribution_energy'):
				#print('distribution_energy received:', value, flush=True)
				valuesplit = value.split(' ')
				denergy = float(valuesplit[0])
		
		#computing power consumed every hour
		if hour != prev_hour: # hour = 100s
			#print ('ts: ',ts, 'day:', day, 'ADE: ',AvgsumRealPower[prev_day][prev_hour], flush = True)
			sumRealPower[prev_hour] = denergy - denergy_prev #energy, not power
			AvgsumRealPower[prev_day][prev_hour] = float(sumRealPower[prev_hour])/1000 # power = energy/hour, here hour = 1 # converting into kW
			denergy_prev = denergy
			
			#Storing WPRTM value received
			if day != 0:
				RT[day][hour] = WPRTM

		if prev_day != day:
			#appending RET values from WPDAM values received:
			RET[day] = [(1+m_factor)*i for i in WPDAM for j in range(60)]
			print('RET[day]: ', RET[day], flush = True)
			
			#computing constant cost to the DSO:
			
			if day > 2:
				const_cost = [0.1 * WPDAM[i]*(AvgsumRealPower[day-3][i]) for i in range(24)]
				print('On day:', day, 'DSO const_cost:', const_cost, flush=True)
				variable_cost = [0.1 * RT[day-1][i]*(AvgsumRealPower[day-1][i] - AvgsumRealPower[day-3][i]) for i in range(24)]  # converting into cents
				print('On day:', day, 'DSO variable_cost:', variable_cost, flush=True)
				DSO['energybillCost'] = sum([const_cost[i] + variable_cost[i] for i in range(24)])
				print('On day:', day, 'DSO Energy Bill Cost:', DSO['energybillCost'], 'computed at time t:', ts, flush=True)
			
			

		#skipping initial day, except last hour, #backup, working model:
		if ts > 84600:
			if minute % 5 == 0:
				#print('Revenues at ', ts, 'minute:', minute, flush=True)
				#Computing revenues and cost every 5 minutes and accumulating the revenues/costs
				for i in range(len(RealPowerkWh)):
					if day > 0:
						RealPowerkWh[house_names[i]]['costperinterval'] = 0.1 * RET[prev_day][60*prev_hour + prev_minute] * (RealPowerkWh[house_names[i]]['real_power_kWh'] - RealPowerkWh[house_names[i]]['Prev_real_power_kWh'])  # converting into cents
						RealPowerkWh[house_names[i]]['energybillRevenue'] = RealPowerkWh[house_names[i]]['energybillRevenue'] + RealPowerkWh[house_names[i]]['costperinterval']
						
						#Publishing values:
						RealPower[house_names[i]] = {'RealPowerkWh': {'costperinterval': RealPowerkWh[house_names[i]]['costperinterval']}}
						fncs_publishString = json.dumps(RealPower[house_names[i]])
						fncs.publish(house_names[i]+'/costperinterval', RealPowerkWh[house_names[i]]['costperinterval'])
					if prev_day != day:
						print ('checking energybillRevenue for ',house_names[i], ':', RealPowerkWh[house_names[i]]['energybillRevenue'] , flush = True)
					RealPowerkWh[house_names[i]]['Prev_real_power_kWh'] = RealPowerkWh[house_names[i]]['real_power_kWh'] #here

		if prev_day != day and day > 2:
			for i in range(len(RealPowerkWh)):
				RealPowerkWh[house_names[i]]['Powerfinalval'] = RealPowerkWh[house_names[i]]['real_power_kWh']
			breakeven = checkbreakeven(day)
			for i in range(len(RealPowerkWh)):
				RealPowerkWh[house_names[i]]['Powerinitval'] = RealPowerkWh[house_names[i]]['real_power_kWh']
		
		if prev_day!= day:
			DSO['energybillCost'] = 0.0
			for j in range(len(RealPowerkWh)):
				RealPowerkWh[house_names[j]]['energybillRevenue'] = 0.0
		
		if ts == 0:
			base_line = getfromcsv(0,0)

		#loadforecast DAM:
		if (day>0):
			if (ts%((day)*(day_len))) == 0:
				#print ('AvgsumRealPower1: ',AvgsumRealPower[day-1], flush = True) # currently this is in W 
				temp = [float(i)/1000 for i in AvgsumRealPower[day-1]] # converting into MW
				#print ('ts2: ',ts, 'day:', day, 'loadforecast_DAM ADE: ',AvgsumRealPower[day-1], flush = True) # after converting into MW
				loadforecast_DAM(temp, hour, day) 

		if(len(load)!=0):
			for i in range(len(load)):
				if(ts >= load[i][0]):
					if(ts == int(load[i][0])):
						#print('ts5: ',ts, 'Publishing loadforecast to AMES: ', load[i][0], str(load[i][1]), load[i][2], flush = True)
						fncs.publish(str(load[i][1]), load[i][2])
				else:
					break

		#if (ts % deltaT == 0 and ts !=0) :
		if(ts < (timeSim + deltaT)) :
			ts = fncs.time_request(timeSim + deltaT)
		else:
			timeSim = timeSim + deltaT
			#check about time
			day = int(ts / day_len)# - ts % 2400 # day = 24*100s $ day_len = 2400s
			hour = int((ts - (day * day_len)) / hour_len)
			minute = int((ts - (day * day_len) - hour * hour_len)/60)
			if day>1: # hour = 100s
				base_line = 1000 * AvgsumRealPower[day-2][hour]
			else:
				base_line = getfromcsv(day, hour)
			power_error = base_line - distribution_load
			hvac = SumMayRunON + SumMustON
			sub_time= sub_time+1
			ErrorSignalNew = power_error + SumMayRunON
			#Pi_Cleared, ErrorMet = calc_retail_price(ErrorSignalNew, P, Pi, SumMayRunON)
			#d_loadNew = distribution_load + float(ErrorMet) - float(SumMayRunON)
			
			if sub_time >=num_sub_intervals:
				#publishing clear price every 5 minutes
				sub_time=0
				Pi_Cleared = RET[day][hour*60]
				publish_Price(Pi_Cleared)
			ts = fncs.time_request(timeSim + deltaT)
			#print('************************************************', flush=True)

		if prev_day != day and day > 2:
			outfile = open('plotdata_' + '_' + str(day-1) + '.json', 'w') 
			json.dump(json_data, outfile)
			outfile.close()
			json_data = {}
			json_data['RETPrice'] = []
			json_data['dload'] = []
			#json_data['bline'] = []
			#json_data['hvac_load'] = []

		if day > 1:
			if ts % samplingtime ==0:
				json_data['dload'].append(distribution_load)
				json_data['RETPrice'].append(Pi_Cleared)
				#json_data['bline'].append(base_line)
				#json_data['hvac_load'].append(SumHvacLoad) # not converting into MW

		
		prev_minute = minute
		prev_hour = hour
		prev_day = day
	
	#plot function:
	#plot_fn()
	print ('finalizing FNCS', flush=True)
	fncs.finalize()

