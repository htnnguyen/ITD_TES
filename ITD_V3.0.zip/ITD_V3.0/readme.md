1. To create the initialization files for the agents:

	python .\prep_agents.py IEEE13_180_Total

	Note: Argument for 180 houses - IEEE13_180_Total and for 360 houses - IEEE13_360_Total

	Files generated:

	- Input json files for auction and house agents
	- fncs config file (IEEE13_180_Total_FNCS_Config.txt) for GridLAB-D

2. To create yaml file (auction.yaml) for auction agent:

	python .\PrepAuctionYaml.py

	Note: Number of houses are changed inside PrepAuctionYaml.py

3. .\runAMES.bat
