# import from library or functions
import fncs
import sys
import re

def hvac_bidding_curve(clear_price, pstar):
	if clear_price > pstar:
		return 0
	else:
		return 1


#HVAC_optimal_price
def hvac_optimal_price(ta, t1, t2,n):
	pmax = 0.1
	x= ((ta - t1)/(t2 - t1))
	price =(x**n) * pmax	
	if x<0:
		if price >0:
			price=-price
	return price

def house_control(houseID,value,ta):
	fncs.publish(houseID+'_heating_setpoint', 55)
	if value==0:
		T=90
		#fncs.publish(houseID+'_cooling_setpoint', T)
		#turn off
	if value==1:
		T=60
		#fncs.publish(houseID+'_cooling_setpoint', T)
		 #turn on
	return T
   
ta=72
band = 5 
t1=72-band
t2=72+band
houseID =sys.argv[1]
#fncs.initialize()
time_granted = 0 # time variable for checking the retuned time from FNCS
timeSim= 0
tf = 24 # simulation time in hours
deltaT = 300 # simulation time interval in seconds, which usually the same as controller period 
#change yaml file to be one minutes
power=3*1000
T_new=72
#unit is W
clear_price=00


while (time_granted < tf*3600):
    # =================Simulation for each time step ============================================ 
    # Initialization when time = 0
	if time_granted == 0:
		fncs.initialize()
	if time_granted != 0:
		events = fncs.get_events()
		for key in events:
			topic = key.decode()
			if topic =='clear_price':
				value = float(fncs.get_value(key).decode())
				clear_price=value
				print(clear_price)
				power_on_off=hvac_bidding_curve(clear_price, pstar)
				T_new=house_control(houseID, power_on_off,ta) #turn on/off HVAC based on cleared price from DSO
				fncs.publish(houseID+'_cooling_setpoint', T_new)


			#send the power consumption
			if topic == houseID+'_hvac_load':
				value = fncs.get_value(key).decode()
				if value.endswith('kW'):
					value=value.replace('kW', '')
					value=value.replace('+', '')
					rt_value = float(value)*1000
					if rt_value > 0:
						power=rt_value
					fncs.publish(houseID+'_rt_power', rt_value)
					fncs.publish(houseID+'_power_level', power)

			#-Reading house parameters
			if topic == houseID+'_temp':
				value = fncs.get_value(key).decode()
				value=value.replace('degF', '')
				ta= float(value)  #reading indoor temperature 
				pstar = hvac_optimal_price(ta, t1, t2, 2)
				fncs.publish(houseID+'_bidding_curves_pistar', pstar)

	if (time_granted < (timeSim + deltaT)) :
		time_granted = fncs.time_request(timeSim + deltaT)
	else:
		timeSim = timeSim + deltaT
		time_granted = fncs.time_request(timeSim + deltaT)
		




fncs.finalize()        
