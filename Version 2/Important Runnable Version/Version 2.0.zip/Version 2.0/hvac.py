import matplotlib.pyplot as plt
#import numpy as np
import random

#HVAC_bidding_curve
def hvac_bidding_curve(pval, pstar):
	result = []
	for i in pval:
		if i > pstar:
			result.append(0)
		else:
			result.append(1)
	return result

#HVAC_optimal_price
def hvac_optimal_price(ta, t1, t2):
	pmax = 100
	return ((ta - t1)/(t2 - t1)) * pmax	

#Sorting Dictionary
def hvac_sort_houses(house_pistar):
	return (sorted(house_pistar.items(), key = lambda x: x[1]))

	
#Testbench:
#Generating house indices
h_index = []	
for i in range(1,16):
	for j in range(1,13):
		h_index.append('house ' + str(i) + '_' +  str(j))

#Randomly generating pistar values for 180 houses
pistar = []
for i in range(180):
	pistar.append(random.randint(1,100))

#Dictionary with key = house_id and value = pistar
house_pistar = {}
for i in range(180):
	house_pistar[h_index[i]] = pistar[i]

#Printing Dictionary
print('Dictionary: ')
print(house_pistar)
print('Sorted dictionary: ')
print(hvac_sort_houses(house_pistar))
	
##data to plot the curves
#tval = np.arange(70.0, 80.0, 0.1)
#pricerange = np.arange(0.0,100.0,0.1)
#t1 = 70
#t2 = 80
#ta = 75

##plotting functions
#plt.figure(1)
#plt.subplot(211)
#plt.plot(pricerange, hvac_bidding_curve(pricerange, hvac_optimal_price(ta, t1, t2)))

#plt.subplot(212)
#plt.plot(tval, hvac_optimal_price(tval,t1,t2))
#plt.show()