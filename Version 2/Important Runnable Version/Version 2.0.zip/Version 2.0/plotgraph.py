from matplotlib import pyplot as plt
import math
import csv
import sys
import numpy as np

f = open('base_line.txt','r')
lines=f.readlines()
result=[]
for x in lines:
	result.append(x)
f.close()

old_stdout = sys.stdout
log_file = open("base_line.player","w")
sys.stdout = log_file

print ('#time	topic  value')
k=0
for i in range(25):
	for j in range(60):
		x=(60*i + 60*60 *j)*1000000000
		print(x,' ','base_line',' ',result[k])
		k=k+1

sys.stdout = old_stdout
log_file.close()
