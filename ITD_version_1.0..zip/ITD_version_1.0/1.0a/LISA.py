# import from library or functions
import fncs
import sys
import os
from initialization import NDay, mode, ta, Tbliss, Tmax, Tmin, Tank_new, wh_ta, wh_Tmin, wh_Tbliss, wh_Tmax, list_agents
from TESagents import HVAC, water_heater, LISA  #

#fncs.initialize()
tf = 24*NDay
deltaT = 300 # simulation time interval in seconds, which usually the same as controller period 
houseID =sys.argv[1]

LISA = LISA(Tmin, Tmax, Tbliss,wh_Tmin, wh_Tmax, wh_Tbliss,houseID,list_agents)
LISA.operate(tf,deltaT)
#list_agents = ['HVAC','water_heater'];