import fncs

#********************************************************************************************************************************************************************************************
#									HVAC AGENT
#********************************************************************************************************************************************************************************************

class HVAC:
	def __init__(self, Tmin, Tmax, Tbliss, houseID):
	#initialization
		self.Tmin = Tmin
		self.Tmax = Tmax
		self.Tbliss = Tbliss
		self.pmax = 40
		self.ta = 72
		self.bid_price ='na'
		self.bid_power =3*1000
		self.actual_power =0
		self.n = 1
		#upate gridlabD setpoint to on/off HVAC
		self.T =72
		self.on =False
		self.ID = houseID
		self.T_default= 72
		self.flag_power = False
		self.flag_temp =False
		self.flag =False

	def initialize_mode(self):
		if self.n ==1:
			fncs.publish(self.ID+'_heating_setpoint', 55)
			fncs.publish(self.ID+'_cooling_setpoint', self.T_default)
	def operate_mode(self):
		fncs.publish(self.ID+'_cooling_setpoint', self.T)

	def GridLABD_update(self, flag_ini):
		if flag_ini:
			self.initialize_mode()
		else:
			self.operate_mode()

	def bid(self):
		#n=1: for cooling system, n= 0: for heating system
		#n=2*n-1 #1=>1, 0 => -1
		x1= ((self.ta - self.Tbliss)/(self.Tmax - self.Tbliss))
		x2= ((self.Tbliss - self.ta)/(self.Tbliss - self.Tmin))
		if self.n==1: #cooling season
			if self.ta<self.Tmin:
				price=(-self.pmax-0.001)
			elif ((self.Tmin <= self.ta) and (self.ta < self.Tbliss)):
				price = -self.pmax*x2
			elif ((self.Tbliss <= self.ta) and (self.ta <= self.Tmax)):
				price= self.pmax*x1
			else:
				price= (self.pmax+0.001)
		else: #heating season
			if self.ta<self.Tmin:
				price=(self.pmax+ 0.001)
			elif ((self.Tmin <= self.ta) and (self.ta < self.Tbliss)):
				price = 1*self.pmax*x2
			elif ((self.Tbliss <= self.ta) and (self.ta <= self.Tmax)):
				price= 1*self.pmax*x1
			else:
				price= (-self.pmax-0.001)
		self.bid_price = price

	def price_response(self,price):
	    # modify for the case heating 
		if self.bid_price != 'na':
			self.on =False if (price > self.bid_price)  else True   #determine on/off status based on DSO's price abd HVAC bid_price 
			self.T = 60 if (self.on) else 100  #turn on/off HVAC based on cleared price from DSO

	def GridLABD_read(self, list_topic,events,flag_price):
		if (self.ID+'_hvac_power') in list_topic:
			key=events[list_topic.index(self.ID+'_hvac_power')]
			value = fncs.get_value(key).decode(); value=value.replace('kVA', '');value=value.replace(' ',''); value = complex(value) #get the number in complex form
			self.actual_power=float(value.real)*1000
			if self.actual_power > 0:
				self.bid_power=self.actual_power
			if flag_price:
				self.flag_power = True

		if (self.ID+'_temp') in list_topic:
			key=events[list_topic.index(self.ID+'_temp')]
			value = fncs.get_value(key).decode()
			value=value.replace('degF', '')
			self.ta= float(value)  #reading indoor temperature 
#			temp_deviation = ta -72  ##Tbliss=72
			self.bid()
			if flag_price:
				self.flag_temp = True
		self.flag = self.flag_power  and self.flag_temp

	def reset_flag(self):
		self.flag_power = False
		self.flag_temp =False

#********************************************************************************************************************************************************************************************
#									Water Heater Agent
#********************************************************************************************************************************************************************************************

class water_heater:
	def __init__(self, wh_Tmin, wh_Tmax, wh_Tbliss, houseID):
	#initialization
		self.Tmin = wh_Tmin
		self.Tmax = wh_Tmax
		self.Tbliss = wh_Tbliss
		self.pmax = 40
		self.ta = 110
		self.bid_price ='na'
		self.bid_power =1.5*1000
		self.power_level =1.5*1000
		self.actual_power =0
		self.n = 0 #heating  mode
		#upate gridlabD setpoint to on/off water heater
		self.T =110
		self.on =False
		self.ID = houseID
		self.T_default= 110
		self.flag_power = False
		self.flag_temp =False
		self.model = False
		self.flag =False
		
	def operate_mode(self):
		fncs.publish(self.ID+'_waterheater.tank_setpoint', self.T)
		
	def initialize_mode(self):
		fncs.publish(self.ID+'_waterheater.tank_setpoint', self.T_default)
		
	def GridLABD_update(self, flag_ini):
		if flag_ini:
			self.initialize_mode()
		else:
			self.operate_mode()

	def bid(self):
		x1= ((self.ta - self.Tbliss)/(self.Tmax - self.Tbliss))
		x2= ((self.Tbliss - self.ta)/(self.Tbliss - self.Tmin))
		if self.n==1: #cooling mode is not applicable for water heater
			self.n =0
		if self.ta<self.Tmin:
			price=(self.pmax+ 0.001)
		elif ((self.Tmin <= self.ta) and (self.ta < self.Tbliss)):
			price = self.pmax*x2
		elif ((self.Tbliss <= self.ta) and (self.ta <= self.Tmax)):
			price= self.pmax*x1
		else:
			price= (-self.pmax-0.001)
		self.bid_price = price
		if self.model ==2:
			self.bid_price=0.0
			self.bid_power=0.0
	def price_response(self,price):
		if self.bid_price != 'na':
			self.on =False if (price > self.bid_price)  else True   #determine on/off status based on DSO's price abd WH bid_price 
			self.T = 160 if (self.on) else 90  #turn on/off WH based on cleared price from DSO

	def GridLABD_read(self, list_topic,events, flag_price):
		if (self.ID+'_waterheater.actual_load') in list_topic:
			key=events[list_topic.index(self.ID+'_waterheater.actual_load')] 
			value = fncs.get_value(key).decode()
			if value.endswith('kVA'):
				value=value.replace('kVA', '')
				value=value.replace(' ','')
				value = complex(value)
				self.actual_power =float(value.real)*1000
				if self.actual_power > 0:
					self.power_level= self.actual_power
			if flag_price:
				self.flag_power= True #the water_heater_power is already read after control action is taken
			if self.model ==2:
				self.bid_price=0.0
				self.bid_power=0.0
			else:
				self.bid_power=self.power_level

		if (self.ID+'_waterheater.waterheater_model') in list_topic:
			key=events[list_topic.index(self.ID+'_waterheater.waterheater_model')] 
			value = fncs.get_value(key).decode()
			if value =='ONEZNODE':
				self.model = 1#can bid
			else:
				self.model = 2 #cannot bid
				self.bid_price=0.0
				self.bid_power=0.0

		if (self.ID+'_waterheater.temperature') in list_topic:
			key=events[list_topic.index(self.ID+'_waterheater.temperature')]
			value = fncs.get_value(key).decode()
			value=value.replace('degF', '')
			self.ta= float(value)  #reading inlet water temperature 
			self.bid()
			if flag_price :
				self.flag_temp = True
		self.flag= self.flag_power and self.flag_temp and (self.model>0)

	def reset_flag(self):
		self.flag_power = False
		self.flag_temp =False
		self.model =0

class LISA:
	def __init__(self,Tmin, Tmax, Tbliss,wh_Tmin, wh_Tmax, wh_Tbliss,houseID,list_agents):
		self.flag_price =False#receive price 
		self.flag_ini =True #start the initial condition of the simulation 
		self.ID = houseID
		self.agents=[]
		self.key =''
		self.clear_price =0 
		for item in list_agents:
			if item =='HVAC':
				self.agents.append(HVAC(Tmin, Tmax, Tbliss, houseID))
				self.key =self.key+'h'
			if item =='water_heater':
				self.agents.append(water_heater(wh_Tmin, wh_Tmax, wh_Tbliss, houseID))
				self.key = self.key +'w'
	

	def agent_send_message_to_GridLABD(self):
		for agent in self.agents:
			agent.price_response(self.clear_price)
		if (not(self.flag_price)):
			self.flag_price =True
			for agent in self.agents:
				agent.GridLABD_update(self.flag_ini)
			if self.flag_ini:
				self.flag_ini=False 
				
	def price_response(self,list_topic,events):
		if 'clear_price' in list_topic:
			key=events[list_topic.index('clear_price')]
			value = fncs.get_value(key).decode()
			self.clear_price =float(value)
			self.agent_send_message_to_GridLABD()
	def GridLABD_to_agents(self,list_topic,events):
		for agent in self.agents:
			agent.GridLABD_read(list_topic,events,self.flag_price) 

	def to_DSO(self):
		flag = True
		for agent in self.agents:
			flag = flag and agent.flag
		if flag: #construct  new bidding curves when all agents updated
			bid_message=''; # bid_power_message1=[]; bid_power_message2=[];
			for agent in self.agents:
				bid_message = bid_message+ '%.10f' % agent.bid_price + '&'+'%.10f' % agent.bid_power + '&'+'%.10f'  % agent.actual_power+'&'
			bid_message = self.key+ '&' + bid_message[:-1] # remove & at the end of the message to save memomry, add key to show the order of bid message
			fncs.publish(self.ID+'_message', bid_message)

	def reset(self):
		self.flag_price =False 
		for agent in self.agents:
			agent.reset_flag()
			
	def operate(self,tf,deltaT):
		time_granted = 0 # time variable for checking the retuned time from FNCS
		timeSim= 0
		while (time_granted < tf*3600):
			if time_granted == 0:
				fncs.initialize()
				for agent in self.agents:
					agent.initialize_mode()
			if time_granted != 0:
				events = fncs.get_events()
				list_topic = [key.decode() for key in events]

				self.price_response(list_topic,events) #receive price from DSO, forward it to agents and ask agents to react
				self.GridLABD_to_agents(list_topic,events) #ask agents to update themselves based on new GridLABD data
				self.to_DSO() #aggregate the bid messages from all agents and send to DSO

			if (time_granted < (timeSim + deltaT)) :
				time_granted = fncs.time_request(timeSim + deltaT)
			else:
				timeSim = timeSim + deltaT
				time_granted = fncs.time_request(timeSim + deltaT)
				self.reset()
		fncs.finalize() 