mode=3
NDay=6

ta=72
Tbliss=72
Tmax=76
Tmin=68

#####Water-heater initialization 
Tank_new = 120
wh_ta = 120
wh_Tmin= 100
wh_Tbliss=120
wh_Tmax=140

#declare list of controllable devices in one house
list_agents =['HVAC','water_heater']