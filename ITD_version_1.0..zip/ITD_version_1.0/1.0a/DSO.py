#	Copyright (C) 2017 Battelle Memorial Institute

# KEEP THE CODE SIMPLE AND EFFICIENT KEEP THE CODE SIMPLE AND EFFICIENT KEEP THE CODE SIMPLE AND EFFICIENT 
#import json
#import sys
import fncs
from numpy import real
#import json
import matplotlib.pyplot as plt
from statistics import mean
from matplotlib.pyplot import subplot, xlabel, ylabel, plot, draw, pause, savefig, close

#mode=4
#NDay=9

import os
import sys
scriptpath = "C:/ITD/Version2.3b/initialization.py"
sys.path.append(os.path.abspath(scriptpath))

from initialization import NDay, mode 

#growth_factor =1.1

import time
import datetime
ts = time.time()
st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

def total_tcl_load(list_hvac_rt_power,list_waterheater_rt_power,mode):
	if mode==1:
		total_tcl= sum(list_hvac_rt_power)
		# sum([sum(list_hvac_rt_power[i]) for i in range(len(list_hvac_rt_power))])
	elif mode==2:
		total_tcl= sum(list_waterheater_rt_power) #sum([sum(list_waterheater_rt_power[i]) for i in range(len(list_hvac_rt_power))])
	else:
		total_tcl = sum(list_hvac_rt_power) + sum(list_waterheater_rt_power) #sum([sum(list_hvac_rt_power[i]) for i in range(len(list_hvac_rt_power))]) + sum([sum(list_waterheater_rt_power[j]) for j in range(len(list_hvac_rt_power))])
	return total_tcl

def plot_single_hours(hvac_powers, hvac_prices, waterheater_powers,waterheater_prices):
	hvac_powers=[hvac_powers[i]/1000 for i in range(len(hvac_powers))]
	waterheater_powers=[waterheater_powers[i]/1000 for i in range(len(waterheater_powers))]
	subplot(211)
	ylabel('HVAC Power (kW)')
	plot(hvac_prices, hvac_powers)
	subplot(212)
	ylabel('Water Heater Power (kW)')
	xlabel('Price (cents/kWh)' )
#	Current simulation time: hour '+str(hour)+' minute '+str(minute))
	plot(waterheater_prices,waterheater_powers)

def plot_single_hours_single(powers, prices):
	powers=[powers[i]/1000 for i in range(len(powers))]
	ylabel('Power (kW)')
	plot(prices, powers)
	xlabel('Price (cents/kWh)' )

#	Current simulation time: hour '+str(hour)+' minute '+str(minute))

	
def market_clearing(power_error,total_tcl,list_pistar_hvac,list_pistar_waterheater,list_hvac_power_level,list_waterheater_power_level,list_hvac_rt_power, list_waterheater_rt_power, mode):
	#market clearing process based on PowerMathcher
	pmax=40
	price_mode=2
	# if mode =1  use hvac only
	#   mode =2 use waterheater only
	#   mode =3 use both hvac+water heater
	if mode ==1:
		power = list_hvac_power_level # [list_hvac_power_level[i][j] for i in range(15) for j in range(36)]
		price= list_pistar_hvac #[list_pistar_hvac[i][j] for i in range(15) for j in range(36)]
	elif mode==2:
		power = list_waterheater_power_level #[list_waterheater_power_level[i][j] for i in range(15) for j in range(36)]
		price= list_pistar_waterheater #[list_pistar_waterheater[i][j] for i in range(15) for j in range(36)]
	elif mode==3: 
		power = list_waterheater_power_level+ list_hvac_power_level #[list_waterheater_power_level[i][j] for i in range(15) for j in range(36)]+[list_hvac_power_level[i][j] for i in range(15) for j in range(36)]
		price= list_pistar_waterheater+ list_pistar_hvac #[list_pistar_waterheater[i][j] for i in range(15) for j in range(36)] + [list_pistar_hvac[i][j] for i in range(15) for j in range(36)]
	else: #dual pricing for hvac and waterheater 
		hvac_power =list_hvac_power_level # [list_hvac_power_level[i][j] for i in range(15) for j in range(36)]
		hvac_price= list_pistar_hvac #[list_pistar_hvac[i][j] for i in range(15) for j in range(36)]
		waterheater_power = list_waterheater_power_level # [list_waterheater_power_level[i][j] for i in range(15) for j in range(36)]
		waterheater_price= list_pistar_waterheater #[list_pistar_waterheater[i][j] for i in range(15) for j in range(36)]

	if mode<4: #single pricing
		price = sorted(price) #sorted price (increasing order)
		sort_index=sorted(range(len(price)), key=lambda k: price[k])
	#create the aggregated power curve
		power = [ power[i] for i in sort_index]
	#reactive_power = [ reactive_power[i] for i in sort_index]
	# use list comprehension 
		acc_power = [sum(power[i:]) for i in range(len(power))]
	#acc_reactive_power = [sum(reactive_power[i:]) for i in range(len(price))]
		ref_tcl_load= total_tcl + power_error
		index = min(range(len(acc_power)), key=lambda i: abs(acc_power[i]-ref_tcl_load) )
		clear_price = max(-pmax, min(pmax, price[index]))*1.0 #get the price from the aggregated bid and bound it in range -pmax pmax
		
		print('previous tcl load: ', total_tcl)
		print('new reference tcl load: ', ref_tcl_load)
		
		
	else:
		waterheater_price = sorted(waterheater_price) #sorted price (increasing order)
		sort_index=sorted(range(len(waterheater_price)), key=lambda k: waterheater_price[k])
		waterheater_power = [waterheater_power[i] for i in sort_index]
		acc_power = [sum(waterheater_power[i:]) for i in range(len(waterheater_price))]
		waterheater_power_curve=acc_power
		
		ref_tcl_load= total_tcl + power_error
		index = min(range(len(acc_power)), key=lambda i: abs(acc_power[i]-ref_tcl_load) )
		clear_hvac_price = max(-pmax, min(pmax, hvac_price[index]))*1.0 #get the price from the aggregated bid and bound it in range -pmax pmax
		
		power_error= ref_tcl_load-acc_power[index]
		#now water heater
		hvac_price = sorted(hvac_price) #sorted price (increasing order)
		sort_index=sorted(range(len(hvac_price)), key=lambda k: hvac_price[k])
		hvac_power = [hvac_power[i] for i in sort_index]
		acc_power = [sum(hvac_power[i:]) for i in range(len(hvac_price))]
		hvac_power_curve=acc_power
		
		#ref_tcl_load= sum([sum(list_waterheater_rt_power[i]) for i in range(len(list_waterheater_rt_power))]) + power_error
		ref_tcl_load= sum(list_waterheater_rt_power) + power_error
		index = min(range(len(acc_power)), key=lambda i: abs(acc_power[i]-ref_tcl_load) )
		clear_waterheater_price = max(-pmax, min(pmax, waterheater_price[index]))*1.0
		clear_price = '%.10f' % clear_hvac_price + '&'+'%.10f' %clear_waterheater_price
	if mode ==4:
		return {'clear_price':clear_price, 'acc_power':acc_power, 'hvac_prices':hvac_price, 'hvac_powers': hvac_power_curve, 'waterheater_powers':waterheater_power_curve, 'waterheater_prices': waterheater_price}
	else:
		return {'clear_price':clear_price, 'powers':acc_power, 'prices': price}
	
# fncs.initialize()

houseID = [[0 for j in range(36)] for i in range(15)] 
#list_pistar_hvac = [[0 for j in range(36)] for i in range(15)] 
list_pistar_waterheater = [[0 for j in range(36)] for i in range(15)] 
list_rt_power= [[0 for j in range(36)] for i in range(15)] 
list_hvac_power_level = [[0 for j in range(36)] for i in range(15)] 
list_waterheater_power_level = [[0 for j in range(36)] for i in range(15)] 
list_reactive_power_level = [[0 for j in range(36)] for i in range(15)]
list_hvac_rt_power = [[0 for j in range(36)] for i in range(15)]
list_waterheater_rt_power = [[0 for j in range(36)] for i in range(15)]


for i in range(15):
	for j in range(36):
		houseID[i][j]='house_'+str(i+1)+'_'+str(j+1)#add controller variable name dynamically


time_granted = 0 # time variable for checking the retuned time from FNCS
timeSim= 0
value =0
#tf = 24 # simulation time in hours
tf = NDay*24
deltaT = 300  # simulation time interval in seconds(minutes), which usually the same as controller period 
num_sub_intervals = int(300/deltaT)

hour_factor = 3600/(deltaT) #1 hour = ? time intervals .e.g one hour = 120 (30 sec) intervals
minute_factor =60/(deltaT)
#the market price is annouced every 5 mins

power_error=0
pmax=40
flag=0
clprice=[]
hvac_clprice=[]
waterheater_clprice=[]
dload=[]
bline=[]
count_min=0
count_hour=0
original_base_line=[]

distribution_load=0
base_line=0

flag_distribution_load=0
flag_baseline=0
flag_message=[0 for i in range(15*36)]


list_pistar_hvac= [0 for i in range(15*36)]
list_hvac_power_level = [0 for i in range(15*36)]
list_hvac_rt_power = [0 for i in range(15*36)]
list_waterheater_rt_power = [0 for i in range(15*36)]
list_waterheater_power_level = [0 for i in range(15*36)]
list_pistar_waterheater = [0 for i in range(15*36)]

flag_clear_market =0 
Loadforecast_DA =[0 for i in range(24)]
sub_time=0

while (time_granted < tf*3600):
	# =================Simulation for each time step ============================================ 
	# Initialization when time = 0
	if time_granted == 0:
		fncs.initialize()
		sub_time=0
	if time_granted != 0:
		events = fncs.get_events()

#---ORIGINAL CODES WORKING FINE BUT WE MODIFY TO "IN" STATEMENT TO INCREASE THE SPEED
		list_topic=[key.decode() for key in events]
		#---ONLY WORK FOR 24 FIRST HOUR------------------
		if 'base_line' in list_topic:
			value = float(fncs.get_value(events[list_topic.index('base_line')]).decode())
			base_line= value
			base_line=base_line*3
		if 'distribution_load' in list_topic:
			value = fncs.get_value(events[list_topic.index('distribution_load')]).decode()
			value = value.replace('VA', '')
			distribution_load=real(complex(value))
			
			
		#-----------------------------------------------------------------------------------------------
		#------------------Decode message from house --------------------------------------------------*
		#-----------------------------------------------------------------------------------------------
		for i in range(15):
			for j in range(36):
			# read and decode the message from house ID 
				if (houseID[i][j]+ '_message') in list_topic:
					value = fncs.get_value(events[list_topic.index(houseID[i][j]+ '_message')]).decode()
					message=[x.strip() for x in value.split('&')] # remove & from the message 
					message_key =message[0]
					message=list(map(float,message[1:])) #convert the string list to float list
					hvac_index= message_key.find('h')
					if hvac_index>-1:
						list_pistar_hvac[36*i+j] =message[3*hvac_index]
						list_hvac_power_level[36*i+j] = message[3*hvac_index+1]
						list_hvac_rt_power[36*i+j] = message[3*hvac_index+2]
					water_heater_index =message_key.find('w')
					if water_heater_index >-1:
						list_waterheater_power_level[36*i+j] =message[3*water_heater_index]
						list_pistar_waterheater[36*i+j] =message[3*water_heater_index+1]
						list_waterheater_rt_power[36*i+j] =message[3*water_heater_index+2]
		if count_hour >= 24:
			base_line = new_base_line[divmod(count_hour,24)[1]] #  divmod(27,24) = (1,3) Day 1 and hour 3 (all count from 0) 
			
		# growth_factor = 2**((count_hour+1)/24)
		# for i in range(24):
			# fncs.publish('loadforecastDAM_h'+str(i), growth_factor*Loadforecast_DA[i]/1000000) 
	if (time_granted < (timeSim + deltaT)):
		time_granted = fncs.time_request(timeSim + deltaT)
	else:
		timeSim = timeSim + deltaT
		power_error= base_line - distribution_load
		#sub_time= sub_time+1
		#total_tcl= hvac_energy_consumtion(list_rt_power)
		total_tcl= total_tcl_load(list_hvac_rt_power,list_waterheater_rt_power,mode)
				#clear price
		market_clearing_results=market_clearing(power_error,total_tcl,list_pistar_hvac, list_pistar_waterheater, list_hvac_power_level, list_waterheater_power_level, list_hvac_rt_power, list_waterheater_rt_power, mode)
		clear_price= market_clearing_results['clear_price']
		fncs.publish('clear_price', clear_price)
		sub_time =0
		hour = int(len(bline)/hour_factor)
		minute = (len(bline)- hour*hour_factor)/(minute_factor)
		print('hour: ', hour, ' minutes: ', int(minute)  )
		print('base_line: ', base_line)
		print('distribution load: ', distribution_load)
		print('power_error= base_line - distribution_load:',power_error)
		dload.append(distribution_load)
		bline.append(base_line)

		print('corresponding_price signal:', clear_price)

		if type(clear_price) is str:
			temp_price =[x.strip() for x in clear_price.split('&')] # remove & from the message 
			hvac_clprice.append(float(temp_price[0]))
			waterheater_clprice.append(float(temp_price[1]))
		else:
			clprice.append(clear_price)
		count_min=count_min +1
		if mode==4:
			plot_single_hours(market_clearing_results['hvac_powers'], market_clearing_results['hvac_prices'], market_clearing_results['waterheater_powers'],market_clearing_results['waterheater_prices'])
		else:
			plot_single_hours_single(market_clearing_results['powers'], market_clearing_results['prices'])
		draw()
		
		# if count_min ==1:
			# # if count_hour in [(24*i-1) for i in range(2,NDay)]:
				# # for i in range(24):
					# # growth_factor = 2**((count_hour+1)/24)
					# # fncs.publish('loadforecastDAM_h'+str(i), growth_factor*Loadforecast_DA[i]/1000000) # publish load forecast of as hourly  of  Day D-1
			# # if count_hour ==23:
					# # interval_zero =0
					# # Loadforecast_DA = [mean(dload[(interval_zero + 12*i) : (interval_zero+ 12*(i+1))]) for i in range (23)]
					# # for i in range(23):
						# # fncs.publish('loadforecastDAM_h'+str(i), Loadforecast_DA[i]/1000000) # publish load forecast of as hourly  of  Day D-1 #test ames wholesale clearing
					# # fncs.publish('loadforecastDAM_h23', mean(dload[-11 :]))

		if count_min==12: #one hour computation
			Loadforecast_RT = mean(dload[-12 :])
			count_min=0
			count_hour=count_hour+1
		#if count_min==0:
			if count_hour in [24*i for i in range(NDay)]:
				#*****************Compute hourly average load as the new base line *****************************
				# Send to AMES after 1 days
				print('*******Load Forecast**************')
				# 1 interval = 5 mins, one day has 24*12 intervals
				interval_zero =(count_hour -24)*12
				Loadforecast_DA = [mean(dload[(interval_zero + 12*i) : (interval_zero+ 12*(i+1))]) for i in range (24)]
				new_base_line=Loadforecast_DA # using load forecast as new baseline to test cobweb
			savefig('5mins in hour'+str(count_hour)+'.png')   # save the figure to file
			close()
		print('************************************************')
		print('************************************************')
		time_granted = fncs.time_request(timeSim + deltaT)
print('*********************check******************')
print(list_waterheater_power_level)

#print(Loadforecast_DA)
print('*******DLOAD**************')
#print(dload)
print('*******BLINE**************')
#print(bline)
print('***********************************Price**************************************************')
#print(clprice)
print('******TIME********')
print(st)
ts = time.time()
st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
print('******END_TIME**********')
print(st)



#Load Forecast = average hourly NO NEED A FOR LOOP

#KEEP THE CODE SIMPLE AND EFFICIENT

#prepare stick
ind =[ i for i in range(0,len(dload)+int(hour_factor),12*int(hour_factor))]

#ind is for every 4 hours

str_stick =[ str(int((i+0.00001)/hour_factor)) for i in ind]
#Plotting dload and bline
fig = plt.figure(1)
plt.subplot(311)
t = range(len(dload))

dloadMW = [dload[i]/1000000 for i in range(len(dload))]
blineMW = [bline[i]/1000000 for i in range(len(bline))]

if mode==3:
	hvac_clprice = clprice
	waterheater_clprice= clprice
p1=plt.plot(t, dloadMW, 'b', )
p2=plt.plot(t, blineMW, 'r', )
plt.xlabel("Time (h)")
plt.ylabel("Power (MW)")
plt.xticks(ind,str_stick)
#plt.grid(True)

#now you can plot the price  clprice ??
plt.subplot(312)
t2 = range(len(hvac_clprice))
p3=plt.plot(t2, hvac_clprice,)
plt.xlabel("Time (h)")
plt.ylabel("A/C Price (cents/kWh)")
plt.xticks(ind,str_stick)


plt.subplot(313)
t2 = range(len(waterheater_clprice))
p4=plt.plot(t2, waterheater_clprice,'g')
plt.xlabel("Time (h)")
plt.ylabel("WH Price (cents/kWh)")
plt.xticks(ind,str_stick)



plt.legend((p1[0], p2[0], p3[0],p4[0]), ('Actual Household Load (Price Controlled)', 'Target Load','HVAC Price Signal', 'Water Heater Price Signal'))
#plt.grid(True)
plt.show()
#show()
fncs.finalize()


#check if it is a number

