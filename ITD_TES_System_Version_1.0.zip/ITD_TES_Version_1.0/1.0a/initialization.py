mode=3
NDay=1

ta=72
Tbliss=72
Tmax=76
Tmin=68

#####Water-heater initialization 
Tank_new = 120
wh_ta = 120
wh_Tmin= 100
wh_Tbliss=120
wh_Tmax=140

#####Ref initialization 
ref_Tmin= 30
ref_Tbliss=35
ref_Tmax=40


#declare list of controllable devices in one house
list__app_agents =['HVAC','water_heater','refrigerator']