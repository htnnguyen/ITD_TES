import sys

for i in range(15):
	for j in range (36):
		old_stdout = sys.stdout
		log_file = open('house_'+str(i+1)+'_'+str(j+1)+'.yaml',"w")
		sys.stdout = log_file
		print('name: house_'+str(i+1)+'_'+str(j+1))
		print('time_delta: 1s')
		print('broker: tcp://localhost:5570')
		print('values:')
		print('    clear_price:')
		print('        topic: DSO/clear_price')
		print('        default: 0.0')
		print('    house_'+str(i+1)+'_'+str(j+1)+'_temp:')
		print('        topic: gridlabdSimulator1/house_'+str(i+1)+'_'+str(j+1)+'_temp')
		print('        default: 0.0')
		
		print('    house_'+str(i+1)+'_'+str(j+1)+'_waterheater.waterheater_model:')
		print('        topic: gridlabdSimulator1/house_'+str(i+1)+'_'+str(j+1)+'_waterheater.waterheater_model')
		print('        default: 0.0')
		
		print('    house_'+str(i+1)+'_'+str(j+1)+'_hvac_power:')
		print('        topic: gridlabdSimulator1/house_'+str(i+1)+'_'+str(j+1)+'_hvac_power')
		print('        default: 0.0')
		
		print('    house_'+str(i+1)+'_'+str(j+1)+'_realPowerkWh:')
		print('        topic: gridlabdSimulator1/house_'+str(i+1)+'_'+str(j+1)+'_realPowerkWh')
		print('        default: 0.0')
		
		print('    house_'+str(i+1)+'_'+str(j+1)+'_waterheater.tank_setpoint:')
		print('        topic: gridlabdSimulator1/house_'+str(i+1)+'_'+str(j+1)+'_waterheater.tank_setpoint')
		print('        default: 0.0')
		
		print('    house_'+str(i+1)+'_'+str(j+1)+'_waterheater.actual_load:')
		print('        topic: gridlabdSimulator1/house_'+str(i+1)+'_'+str(j+1)+'_waterheater.actual_load')
		print('        default: 0.0')
		
		print('    house_'+str(i+1)+'_'+str(j+1)+'_waterheater.temperature:')
		print('        topic: gridlabdSimulator1/house_'+str(i+1)+'_'+str(j+1)+'_waterheater.temperature')
		print('        default: 0.0')

		sys.stdout = old_stdout
		log_file.close()

old_stdout = sys.stdout
log_file = open('DSO_add.yaml',"w")
sys.stdout = log_file
for i in range(15):
	for j in range (36):
		# print('    house_'+str(i+1)+'_'+str(j+1)+'_bidding_curves_pistar:')
		# print('        topic: house_'+str(i+1)+'_'+str(j+1)+'/house_'+str(i+1)+'_'+str(j+1)+'_bidding_curves_pistar')
		# print('        default: 0.0')
		
		# print('    house_'+str(i+1)+'_'+str(j+1)+'_power_level:')
		# print('        topic: house_'+str(i+1)+'_'+str(j+1)+'/house_'+str(i+1)+'_'+str(j+1)+'_power_level')
		# print('        default: 0.0')
		# print('    house_'+str(i+1)+'_'+str(j+1)+'_rt_power:')
		# print('        topic: house_'+str(i+1)+'_'+str(j+1)+'/house_'+str(i+1)+'_'+str(j+1)+'_rt_power')
		# print('        default: 0.0')
		
		# print('    house_'+str(i+1)+'_'+str(j+1)+'_rt_reactive_power:')
		# print('        topic: house_'+str(i+1)+'_'+str(j+1)+'/house_'+str(i+1)+'_'+str(j+1)+'_rt_reactive_power')
		# print('        default: 0.0')
		
		# print('    house_'+str(i+1)+'_'+str(j+1)+'_reactive_power_level:')
		# print('        topic: house_'+str(i+1)+'_'+str(j+1)+'/house_'+str(i+1)+'_'+str(j+1)+'_reactive_power_level')
		# print('        default: 0.0')
		
		print('    house_'+str(i+1)+'_'+str(j+1)+'_message:')
		print('        topic: house_'+str(i+1)+'_'+str(j+1)+'/house_'+str(i+1)+'_'+str(j+1)+'_message')
		print('        default: 0.0')
sys.stdout = old_stdout
log_file.close()
