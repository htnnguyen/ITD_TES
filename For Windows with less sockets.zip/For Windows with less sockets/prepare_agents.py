import sys

for i in range(15):
		old_stdout = sys.stdout
		log_file = open('feeder_'+str(i+1)+'.yaml',"w")
		sys.stdout = log_file
		print('name: feeder_'+str(i+1))
		print('time_delta: 1s')
		print('broker: tcp://localhost:5570')
		print('values:')
		print('    clear_price:')
		print('        topic: DSO/clear_price')
		print('        default: 0.0')
		for j in range (12):
			print('    house_'+str(i+1)+'_'+str(j+1)+'_temp:')
			print('        topic: gridlabdSimulator1/house_'+str(i+1)+'_'+str(j+1)+'_temp')
			print('        default: 0.0')
		
			print('    house_'+str(i+1)+'_'+str(j+1)+'_hvac_load:')
			print('        topic: gridlabdSimulator1/house_'+str(i+1)+'_'+str(j+1)+'_hvac_load')
			print('        default: 0.0')
		sys.stdout = old_stdout
		log_file.close()

old_stdout = sys.stdout
log_file = open('DSO_add.yaml',"w")
sys.stdout = log_file
for i in range(15):
	for j in range (12):
		print('    house_'+str(i+1)+'_'+str(j+1)+'_bidding_curves_pistar:')
		print('        topic: feeder_'+str(i+1)+'/house_'+str(i+1)+'_'+str(j+1)+'_bidding_curves_pistar')
		print('        default: 0.0')
for i in range(15):
	for j in range (12):
		print('    house_'+str(i+1)+'_'+str(j+1)+'_power_level:')
		print('        topic: feeder_'+str(i+1)+'/house_'+str(i+1)+'_'+str(j+1)+'_power_level')
		print('        default: 0.0')
for i in range(15):
	for j in range (12):
		print('    house_'+str(i+1)+'_'+str(j+1)+'_rt_power:')
		print('        topic: feeder_'+str(i+1)+'/house_'+str(i+1)+'_'+str(j+1)+'_rt_power')
		print('        default: 0.0')
sys.stdout = old_stdout
log_file.close()
#subscribe "precommit:house_1_1.heating_setpoint <- house_1_1/house_1_1_heating_setpoint";