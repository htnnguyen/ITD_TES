import math
import csv
import sys

f = open('./output/distribution_load_base_line.csv','r')
reader = csv.reader(f)
val = []
time = []
loadforecast = []

for line in reader:
	if(line[0][0] != '#'):
		val.append(float(line[5]))

for i in range(0,len(val),12):
	sum = 0
	for j in range(i,i+12):
		if(j<=len(val)-1):
			sum = sum + val[j]
	sum = sum/12
	loadforecast.append(sum)
	#val[i:i+12] = [sum for i in range(12)]
		
old_stdout = sys.stdout

log_file = open("loadforecast.player","w")
print(len(loadforecast))

sys.stdout = log_file

print ('#time	topic  value')

loadforecastRTM = [[] for i in range(3)]
loadforecastDAM = []
load = []

for i in range(4):#len(loadforecast)):
	x = ((i+1)*24*10*10)*1000000000 - 5*10*1000000000 - 1*1000000000
	for j in range(24):
		loadforecastDAM.append((x,'loadforecastDAM_h'+str(j), float(loadforecast[j])*0.00001))

for j in range(len(loadforecast)):
	y = (j*10*10)*1000000000 + 24*10*10*1000000000 - 51*1000000000 #10*10*1000000000
	for k in range(3):
		loadforecastRTM[k].append((y, 'loadforecastRTM_'+str(k+1), float(loadforecast[j])*0.00001))
	
load = loadforecastDAM + loadforecastRTM[0] + loadforecastRTM[1] + loadforecastRTM[2]

load = sorted(load, key=lambda x: x[0])

for i in load:
	print(str(i[0])+'	'+str(i[1])+'	'+str(i[2]))

sys.stdout = old_stdout
log_file.close()