
TestCase: AMES with Modified IEEE 13 bus distribution system (fig: 5BusTransmissionGrid_with_ModifiedIEEE13BusDistributionSystem.png)
==========================================================
1.	runAMES.bat
