from matplotlib import pyplot as plt
import math
import csv
import sys
import shutil
import glob
from decimal import *

lse = [float(i) for i in range(24)]

def writetodatfile(lsedataarray):
	lsedatastr = []
	baseload = [250.0000,230.6600,217.8900,211.4400,205.1100,208.2800,211.4400,224.3300,256.3300,282.0000,288.4400,
	291.6100,288.4400,282.0000,278.8300,278.8300,291.6100,320.4400,307.6700,304.3900,301.2200,294.7800,278.8300,259.6100]
	lsedatastr = [str(round(Decimal(lsedataarray[i])+Decimal(baseload[i]), 4)) for i in range(len(lsedataarray))]
	f = open('../ames-2.06-src/DATA/genfiles/5BusTestCase_nolearning_lse.dat', 'w')
	old_stdout = sys.stdout
	sys.stdout = f
	s = '      LSE3	         3	         4'
	strdata = [0 for i in range(3)]
	for i in range(3):
		temp=''
		for j in range(8):
			temp = temp + '	       ' + lsedatastr[j+8*i]
		strdata[i] = temp
	
	#s1 = '      LSE3	         3	         4'#	       '+250.0000+'	       '+230.6600	       217.8900	       211.4400	       205.1100	       208.2800	       211.4400	       224.3300'
	#s1 = '      LSE3	         3	         4'#	       '+250.0000+'	       '+230.6600	       217.8900	       211.4400	       205.1100	       208.2800	       211.4400	       224.3300'
	#s1 = '      LSE3	         3	         4'#	       '+250.0000+'	       '+230.6600	       217.8900	       211.4400	       205.1100	       208.2800	       211.4400	       224.3300'
	
	print ('#LSEDataFixedDemandStart')
	print('//    Name	        ID	     atBus	           H-00	           H-01	           H-02	           H-03	           H-04	           H-05	           H-06	           H-07')
	print('      LSE1	         1	         2	       350.0000	       322.9300	       305.0400	       296.0200	       287.1600	       291.5900	       296.0200	       314.0700')
	print('      LSE2	         2	         3	       300.0000	       276.8000	       261.4700	       253.7300	       246.1300	       249.9300	       253.7300	       269.2000')
	print(s+strdata[0])
	
	print('//    Name	        ID	     atBus	           H-00	           H-01	           H-02	           H-03	           H-04	           H-05	           H-06	           H-07')
	print('      LSE1	         1	         2	       358.8600	       394.8000	       403.8200	       408.2500	       403.8200	       394.8000	       390.3700	       390.3700')
	print('      LSE2	         2	         3	       307.6000	       338.4000	       346.1300	       349.9300	       346.1300	       338.4000	       334.6000	       334.6000')
	print(s+strdata[1])
	
	print('//    Name	        ID	     atBus	           H-00	           H-01	           H-02	           H-03	           H-04	           H-05	           H-06	           H-07')
	print('      LSE1	         1	         2	       408.2500	       448.6200	       430.7300	       426.1400	       421.7100	       412.6900	       390.3700	       363.4600')
	print('      LSE2	         2	         3	       349.9300	       384.5300	       369.2000	       365.2600	       361.4700	       353.7300	       334.6000	       311.5300')
	print(s+strdata[2])
	print('#LSEDataFixedDemandEnd')
	sys.stdout = old_stdout
	f.close()

writetodatfile(lse)

with open('../ames-2.06-src/DATA/genfiles/5BusTestCase_nolearning_combined.dat', 'wb') as outfile:
    for filename in glob.glob('../ames-2.06-src/DATA/genfiles/*.dat'):
        if filename == outfile:
            # don't want to copy the output into the output
            continue
        with open(filename, 'rb') as readfile:
            shutil.copyfileobj(readfile, outfile)

# #LSEDataFixedDemandStart
# //    Name	        ID	     atBus	           H-00	           H-01	           H-02	           H-03	           H-04	           H-05	           H-06	           H-07
      # LSE1	         1	         2	       350.0000	       322.9300	       305.0400	       296.0200	       287.1600	       291.5900	       296.0200	       314.0700
      # LSE2	         2	         3	       300.0000	       276.8000	       261.4700	       253.7300	       246.1300	       249.9300	       253.7300	       269.2000
      # LSE3	         3	         4	       250.0000	       230.6600	       217.8900	       211.4400	       205.1100	       208.2800	       211.4400	       224.3300
# //    Name	        ID	     atBus	           H-08	           H-09	           H-10	           H-11	           H-12	           H-13	           H-14	           H-15
      # LSE1	         1	         2	       358.8600	       394.8000	       403.8200	       408.2500	       403.8200	       394.8000	       390.3700	       390.3700
      # LSE2	         2	         3	       307.6000	       338.4000	       346.1300	       349.9300	       346.1300	       338.4000	       334.6000	       334.6000
      # LSE3	         3	         4	       256.3300	       282.0000	       288.4400	       291.6100	       288.4400	       282.0000	       278.8300	       278.8300
# //    Name	        ID	     atBus	           H-16	           H-17	           H-18	           H-19	           H-20	           H-21	           H-22	           H-23
      # LSE1	         1	         2	       408.2500	       448.6200	       430.7300	       426.1400	       421.7100	       412.6900	       390.3700	       363.4600
      # LSE2	         2	         3	       349.9300	       384.5300	       369.2000	       365.2600	       361.4700	       353.7300	       334.6000	       311.5300
      # LSE3	         3	         4	       291.6100	       320.4400	       307.6700	       304.3900	       301.2200	       294.7800	       278.8300	       259.6100
# #LSEDataFixedDemandEnd
