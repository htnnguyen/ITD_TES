(export FNCS_TRACE=yes && export FNCS_LOG_STDOUT=yes && exec fncs_broker 183 &> broker.log &)
(export FNCS_FATAL=NO && export FNCS_LOG_STDOUT=yes && exec gridlabd IEEE13.glm &> gridlabd.log &)