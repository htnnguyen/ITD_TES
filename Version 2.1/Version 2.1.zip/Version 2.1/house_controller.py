# import from library or functions
import fncs
import sys
import re

def hvac_bidding_curve(clear_price, pstar):
	if clear_price > pstar:
		return 0
	else:
		return 1

#HVAC_optimal_price
def hvac_optimal_price(ta,t0, t1, t2,n):
	pmax = 1
	x1= ((ta - t1)/(t2 - t1))
	x2= ((t1 - ta)/(t1 - t0))
	#price =(x**n) * pmax	
	if ta<t0:
		price=-1000
	elif ((t0 <= ta) and (ta < t1)):
		price = -pmax*x2
	elif ((t1 <= ta) and (ta <= t2)):
		price= pmax*x1
	else:
		price= 1000
	return price
	
def house_control(houseID,value,ta):
	fncs.publish(houseID+'_heating_setpoint', 55)
	if value==0:
		T=100
		#fncs.publish(houseID+'_cooling_setpoint', T)
		#turn off
	if value==1:
		T=50
		#fncs.publish(houseID+'_cooling_setpoint', T)
		 #turn on
	return T

ta=72
band = 2 
t0=72-2*band
t2=72+2*band
t1=72
houseID =sys.argv[1]
#fncs.initialize()
time_granted = 0 # time variable for checking the retuned time from FNCS
timeSim= 0
tf = 24 # simulation time in hours
deltaT = 300 # simulation time interval in seconds, which usually the same as controller period 
#change yaml file to be one minutes
power=3*1000
flag =0
T_new=72
#unit is W
clear_price=00


while (time_granted < tf*3600):
    # =================Simulation for each time step ============================================ 
    # Initialization when time = 0
	if time_granted == 0:
		fncs.initialize()
	if time_granted != 0:
		events = fncs.get_events()
		for key in events:
			topic = key.decode()
			if topic =='clear_price':
				value = float(fncs.get_value(key).decode())
				clear_price=value
				print(clear_price)
				power_on_off=hvac_bidding_curve(clear_price, pstar)
				T_new=house_control(houseID, power_on_off,ta) #turn on/off HVAC based on cleared price from DSO
				fncs.publish(houseID+'_cooling_setpoint', T_new)


			#send the power consumption
			if topic == houseID+'_hvac_load':
				value = fncs.get_value(key).decode()
				if value.endswith('kW'):
					value=value.replace('kW', '')
					value=value.replace('+', '')
					rt_value = float(value)*1000
					if rt_value > 0:
						if flag==0:
							power=rt_value
							flag=1
						else:
							power= 0.5*(power+rt_value)
					fncs.publish(houseID+'_rt_power', rt_value)
					fncs.publish(houseID+'_power_level', power)

			#-Reading house parameters
			if topic == houseID+'_temp':
				value = fncs.get_value(key).decode()
				value=value.replace('degF', '')
				ta= float(value)  #reading indoor temperature 
				pstar = hvac_optimal_price(ta, t0, t1, t2, 1)
				fncs.publish(houseID+'_bidding_curves_pistar', pstar)

	if (time_granted < (timeSim + deltaT)) :
		time_granted = fncs.time_request(timeSim + deltaT)
	else:
		timeSim = timeSim + deltaT
		time_granted = fncs.time_request(timeSim + deltaT)
		




fncs.finalize()        
